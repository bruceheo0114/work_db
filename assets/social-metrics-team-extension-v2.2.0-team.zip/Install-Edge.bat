@echo off
start "" msedge.exe "edge://extensions/"
start "" explorer.exe "%~dp0"
echo.
echo Edge extension page and this folder were opened.
echo Turn on Developer mode, click Load unpacked, and select this folder.
pause
