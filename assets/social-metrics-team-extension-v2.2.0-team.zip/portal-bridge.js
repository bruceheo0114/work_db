"use strict";

const READY_ATTRIBUTE = "data-social-metrics-extension";
document.documentElement.setAttribute(READY_ATTRIBUTE, "ready");
document.dispatchEvent(new CustomEvent("social-metrics-extension-ready"));

document.addEventListener("social-metrics-open", () => {
  chrome.runtime.sendMessage({ type: "OPEN_SOCIAL_METRICS" }).catch(() => {});
});
