"use strict";

// 팀 배포본에 자동 주입된 YouTube Data API v3 전용 제한 키입니다.
globalThis.SOCIAL_METRICS_CONFIG = Object.freeze({
  youtubeApiKey: "AIzaSyAKCEcL55KF4NLZoMZCnfki9vv5_fDmWrc"
});