@echo off
start "" chrome.exe "chrome://extensions/"
start "" explorer.exe "%~dp0"
echo.
echo Chrome extension page and this folder were opened.
echo Turn on Developer mode, click Load unpacked, and select this folder.
pause
