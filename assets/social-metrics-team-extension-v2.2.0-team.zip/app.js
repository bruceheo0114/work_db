"use strict";

const COLS = [
  "플랫폼", "계정", "순번", "유형", "게시일", "조회수", "좋아요", "댓글",
  "참여수", "참여율(%)", "제목", "링크", "수집출처", "비고"
];

const IG_APP_ID = "936619743392459";
const state = { rows: [], errors: [], controller: null, running: false };

const sleep = (ms, signal) => new Promise((resolve, reject) => {
  const timer = setTimeout(resolve, ms);
  if (!signal) return;
  const onAbort = () => {
    clearTimeout(timer);
    reject(new DOMException("사용자가 중지했습니다.", "AbortError"));
  };
  if (signal.aborted) onAbort();
  else signal.addEventListener("abort", onAbort, { once: true });
});

function asNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(String(value).replace(/,/g, ""));
  return Number.isFinite(n) ? n : null;
}

function sanitizeText(value) {
  return String(value ?? "").replace(/[\u0000-\u001F\u007F-\u009F]/g, "").trim();
}

function builtInYoutubeKey() {
  const config = typeof globalThis !== "undefined" ? globalThis.SOCIAL_METRICS_CONFIG : null;
  return sanitizeText(config && config.youtubeApiKey);
}

function parseCountText(value) {
  if (value === null || value === undefined) return null;
  let text = String(value).trim().replace(/\u00a0/g, " ");
  const korean = text.match(/([\d,.]+)\s*(억|만|천)/);
  if (korean) {
    const base = Number(korean[1].replace(/,/g, ""));
    const unit = { "천": 1e3, "만": 1e4, "억": 1e8 }[korean[2]];
    return Number.isFinite(base) ? Math.round(base * unit) : null;
  }
  const compact = text.match(/([\d,.]+)\s*([KMB])/i);
  if (compact) {
    const base = Number(compact[1].replace(/,/g, ""));
    const unit = { K: 1e3, M: 1e6, B: 1e9 }[compact[2].toUpperCase()];
    return Number.isFinite(base) ? Math.round(base * unit) : null;
  }
  const plain = text.match(/\d[\d,.]*/);
  if (!plain) return null;
  const normalized = plain[0].replace(/,/g, "");
  const n = Number(normalized);
  return Number.isFinite(n) ? Math.round(n) : null;
}

function localDateFromUnix(seconds) {
  const d = new Date(Number(seconds) * 1000);
  if (Number.isNaN(d.getTime())) return "";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function isoDate(value) {
  if (!value) return "";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? "" : d.toISOString().slice(0, 10);
}

function cleanLines(text) {
  return [...new Set(String(text || "").split(/\r?\n/).map((s) => s.trim()).filter(Boolean))];
}

function safeMessage(error) {
  if (!error) return "알 수 없는 오류";
  if (error.name === "AbortError") return "사용자가 중지했습니다.";
  return error.message || String(error);
}

async function fetchWithTimeout(url, options = {}, timeoutMs = 30000) {
  const localController = new AbortController();
  const external = options.signal;
  const onAbort = () => localController.abort(external.reason);
  if (external) {
    if (external.aborted) onAbort();
    else external.addEventListener("abort", onAbort, { once: true });
  }
  const timer = setTimeout(() => localController.abort(new DOMException("요청 시간 초과", "TimeoutError")), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: localController.signal });
  } finally {
    clearTimeout(timer);
    if (external) external.removeEventListener("abort", onAbort);
  }
}

function instagramRef(raw) {
  const value = String(raw || "").trim();
  if (!value) throw new Error("빈 Instagram 입력입니다.");
  if (/^https?:\/\//i.test(value)) {
    let url;
    try { url = new URL(value); } catch { throw new Error(`잘못된 Instagram 링크: ${value}`); }
    if (!/(^|\.)instagram\.com$/i.test(url.hostname)) throw new Error(`Instagram 링크가 아닙니다: ${value}`);
    const parts = url.pathname.split("/").filter(Boolean).map(decodeURIComponent);
    if (["p", "reel", "tv"].includes(parts[0]) && parts[1]) return { kind: "media", code: parts[1], raw: value };
    if (!parts[0] || ["accounts", "explore", "stories", "direct", "reels"].includes(parts[0])) {
      throw new Error(`프로필 링크를 확인해 주세요: ${value}`);
    }
    return { kind: "profile", username: parts[0].replace(/^@/, ""), raw: value };
  }
  const username = value.replace(/^@/, "").replace(/\/$/, "");
  if (!/^[A-Za-z0-9._]{1,30}$/.test(username)) throw new Error(`Instagram 계정명을 확인해 주세요: ${value}`);
  return { kind: "profile", username, raw: value };
}

function youtubeRef(raw) {
  const value = String(raw || "").trim();
  if (!value) throw new Error("빈 YouTube 입력입니다.");
  if (/^UC[A-Za-z0-9_-]{20,}$/.test(value)) return { kind: "channelId", value, raw: value };
  if (/^@[^\s/]+$/.test(value)) return { kind: "handle", value, raw: value };
  if (!/^https?:\/\//i.test(value)) return { kind: "handle", value: `@${value}`, raw: value };
  let url;
  try { url = new URL(value); } catch { throw new Error(`잘못된 YouTube 링크: ${value}`); }
  if (!/(^|\.)youtube\.com$/i.test(url.hostname) && url.hostname !== "youtu.be") {
    throw new Error(`YouTube 링크가 아닙니다: ${value}`);
  }
  if (url.hostname === "youtu.be") return { kind: "video", value: url.pathname.split("/").filter(Boolean)[0], raw: value };
  const parts = url.pathname.split("/").filter(Boolean).map(decodeURIComponent);
  if (url.pathname === "/watch" && url.searchParams.get("v")) return { kind: "video", value: url.searchParams.get("v"), raw: value };
  if (parts[0] === "shorts" && parts[1]) return { kind: "video", value: parts[1], raw: value };
  if (parts[0] === "channel" && parts[1]) return { kind: "channelId", value: parts[1], raw: value };
  if (parts[0] && parts[0].startsWith("@")) return { kind: "handle", value: parts[0], raw: value };
  return { kind: "url", value: `${url.origin}/${parts.slice(0, 2).join("/")}`, raw: value };
}

function inputPlatform(raw) {
  const value = String(raw || "").trim();
  if (/^UC[A-Za-z0-9_-]{20,}$/.test(value)) return "youtube";
  if (!/^https?:\/\//i.test(value)) {
    throw new Error(`플랫폼을 자동 구분하려면 전체 링크로 입력해 주세요: ${value}`);
  }
  let url;
  try { url = new URL(value); } catch { throw new Error(`잘못된 링크입니다: ${value}`); }
  if (/(^|\.)instagram\.com$/i.test(url.hostname)) return "instagram";
  if (/(^|\.)youtube\.com$/i.test(url.hostname) || url.hostname === "youtu.be") return "youtube";
  throw new Error(`Instagram 또는 YouTube 링크가 아닙니다: ${value}`);
}

const IG_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
function instagramCodeToPk(code) {
  let id = 0n;
  for (const ch of String(code || "")) {
    const index = IG_ALPHABET.indexOf(ch);
    if (index < 0) return null;
    id = id * 64n + BigInt(index);
  }
  return id.toString();
}

async function instagramHeaders(isPost = false) {
  const headers = {
    "x-ig-app-id": IG_APP_ID,
    "x-requested-with": "XMLHttpRequest",
    "x-asbd-id": "129477",
    "accept": "application/json"
  };
  if (typeof chrome !== "undefined" && chrome.cookies) {
    try {
      const csrf = await chrome.cookies.get({ url: "https://www.instagram.com/", name: "csrftoken" });
      if (csrf && csrf.value) headers["x-csrftoken"] = csrf.value;
    } catch (_) {}
  }
  if (isPost) headers["content-type"] = "application/x-www-form-urlencoded;charset=UTF-8";
  return headers;
}

async function instagramJson(path, options = {}) {
  const method = options.method || "GET";
  const response = await fetchWithTimeout(`https://www.instagram.com${path}`, {
    method,
    credentials: "include",
    cache: "no-store",
    headers: { ...(await instagramHeaders(method === "POST")), ...(options.headers || {}) },
    body: options.body,
    signal: options.signal
  });
  const text = await response.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  const endpoint = `${method} ${path.split("?")[0]}`;
  const serverMessage = sanitizeText(json && (json.message || (json.error && json.error.message))).slice(0, 160);
  let message = "";
  if (response.status === 401) message = "Instagram 로그인이 필요합니다. 로그인 탭을 연 뒤 다시 시도하세요.";
  else if (response.status === 403) message = "Instagram이 요청을 거부했습니다. 로그인 세션 또는 계정 열람 권한을 확인하세요.";
  else if (response.status === 429) message = "Instagram 요청 제한에 걸렸습니다. 10~20분 뒤 계정 수를 줄여 다시 시도하세요.";
  else if (!response.ok) message = `Instagram 요청 실패 (HTTP ${response.status}, ${endpoint}${serverMessage ? ` · ${serverMessage}` : ""})`;
  else if (!json) message = "Instagram이 로그인/보안 확인 페이지를 반환했습니다.";
  else if (json.status === "fail") message = serverMessage || "Instagram 요청이 실패했습니다.";
  if (message) {
    const error = new Error(message);
    error.status = response.status;
    error.path = path.split("?")[0];
    error.method = method;
    throw error;
  }
  return json;
}

async function instagramMediaInfo(code, signal) {
  const pk = instagramCodeToPk(code);
  if (!pk) throw new Error(`게시물 코드를 해석할 수 없습니다: ${code}`);
  const json = await instagramJson(`/api/v1/media/${pk}/info/`, { signal });
  const media = (json.items || [])[0];
  if (!media) throw new Error(`게시물 정보를 찾지 못했습니다: ${code}`);
  return media;
}

async function resolveInstagramProfile(ref, signal) {
  let username = ref.username;
  if (ref.kind === "media") {
    const media = await instagramMediaInfo(ref.code, signal);
    username = media.user && media.user.username;
    if (!username) throw new Error("게시물에서 작성자 계정을 확인하지 못했습니다.");
  }
  try {
    const json = await instagramJson(`/api/v1/users/web_profile_info/?username=${encodeURIComponent(username)}`, { signal });
    const user = (json.data && json.data.user) || json.user;
    if (!user) throw new Error(`Instagram 계정을 찾지 못했습니다: ${username}`);
    const following = user.friendship_status && (user.friendship_status.following || user.friendship_status.is_bestie);
    if (user.is_private && !following) throw new Error(`${user.username} 계정은 비공개이며 현재 로그인 계정이 팔로우하지 않습니다.`);
    return { id: user.id || user.pk ? String(user.id || user.pk) : null, username: user.username || username, user, warnings: [] };
  } catch (error) {
    if (![400, 404].includes(error.status)) throw error;
    return {
      id: null,
      username,
      user: null,
      warnings: [`프로필 ID 조회 ${error.status}: 사용자명 기반 피드로 재시도함`]
    };
  }
}

function mediaIdentity(media) {
  return String(media.code || media.pk || media.id || "");
}

function instagramGraphItems(user) {
  const edges = user && user.edge_owner_to_timeline_media && user.edge_owner_to_timeline_media.edges;
  if (!Array.isArray(edges)) return [];
  return edges.map((edge) => edge && edge.node).filter(Boolean).map((node) => {
    const typename = node.__typename || "";
    const captionEdge = node.edge_media_to_caption && node.edge_media_to_caption.edges && node.edge_media_to_caption.edges[0];
    return {
      id: node.id,
      pk: node.id,
      code: node.shortcode,
      taken_at: node.taken_at_timestamp,
      media_type: typename === "GraphSidecar" ? 8 : (typename === "GraphVideo" ? 2 : 1),
      product_type: node.product_type || (node.is_video && node.video_view_count !== undefined ? "feed" : undefined),
      like_count: node.edge_media_preview_like ? node.edge_media_preview_like.count : (node.edge_liked_by && node.edge_liked_by.count),
      comment_count: node.edge_media_to_comment && node.edge_media_to_comment.count,
      video_view_count: node.video_view_count,
      caption: { text: captionEdge && captionEdge.node ? captionEdge.node.text || "" : "" }
    };
  });
}

async function instagramFeedPage(profile, query, signal) {
  const routes = [];
  if (profile.id) routes.push(`/api/v1/feed/user/${profile.id}/?${query}`);
  routes.push(`/api/v1/feed/user/${encodeURIComponent(profile.username)}/username/?${query}`);
  let lastError;
  for (const route of routes) {
    try { return await instagramJson(route, { signal }); }
    catch (error) {
      lastError = error;
      if (![400, 404].includes(error.status)) throw error;
    }
  }
  throw lastError;
}

async function instagramFeed(profile, wanted, signal) {
  const items = [];
  const seen = new Set();
  let maxId = "";
  for (let page = 0; page < 6 && items.length < wanted; page++) {
    const query = new URLSearchParams({ count: String(Math.min(50, Math.max(12, wanted))) });
    if (maxId) query.set("max_id", maxId);
    let json;
    try { json = await instagramFeedPage(profile, query, signal); }
    catch (error) {
      const graphItems = page === 0 ? instagramGraphItems(profile.user) : [];
      if (graphItems.length) return graphItems;
      throw error;
    }
    for (const item of json.items || []) {
      const key = mediaIdentity(item);
      if (key && !seen.has(key)) { seen.add(key); items.push(item); }
      const itemUser = item.user || {};
      if (!profile.id && (itemUser.pk || itemUser.id)) profile.id = String(itemUser.pk || itemUser.id);
    }
    const paging = json.paging_info || {};
    const next = json.next_max_id || paging.next_max_id || "";
    const more = json.more_available ?? paging.more_available;
    if (!more || !next || next === maxId) break;
    maxId = next;
    await sleep(450, signal);
  }
  return items;
}

async function instagramClips(profile, wanted, signal) {
  if (!profile.id) {
    const error = new Error("Instagram 릴스 목록에 필요한 계정 ID를 확인하지 못했습니다.");
    error.status = 400;
    error.path = "/api/v1/clips/user/";
    throw error;
  }
  const items = [];
  const seen = new Set();
  let maxId = "";
  for (let page = 0; page < 6 && items.length < wanted; page++) {
    const form = new URLSearchParams({
      target_user_id: profile.id,
      page_size: String(Math.min(50, Math.max(12, wanted))),
      include_feed_video: "true"
    });
    if (maxId) form.set("max_id", maxId);
    const json = await instagramJson("/api/v1/clips/user/", { method: "POST", body: form.toString(), signal });
    for (const raw of json.items || []) {
      const item = raw.media || raw;
      const key = mediaIdentity(item);
      if (key && !seen.has(key)) { seen.add(key); items.push(item); }
    }
    const paging = json.paging_info || {};
    const next = paging.next_max_id || json.next_max_id || "";
    if (!(paging.more_available ?? json.more_available) || !next || next === maxId) break;
    maxId = next;
    await sleep(500, signal);
  }
  return items;
}

function instagramType(media) {
  if (media.product_type === "clips") return "릴스";
  if (Number(media.media_type) === 8) return "캐러셀";
  if (Number(media.media_type) === 2) return "동영상";
  if (Number(media.media_type) === 1) return "이미지";
  return String(media.media_type || "콘텐츠");
}

function isInstagramReel(media) {
  return media && (media.product_type === "clips" || media.product_type === "reels");
}

function instagramRow(media, username, rank) {
  const likes = asNumber(media.like_count);
  const comments = asNumber(media.comment_count);
  const viewCandidates = [media.play_count, media.ig_play_count, media.view_count, media.video_view_count];
  const views = viewCandidates.map(asNumber).find((v) => v !== null) ?? null;
  const engagement = likes !== null && comments !== null ? likes + comments : null;
  const rate = views && engagement !== null ? Math.round((engagement * 10000) / views) / 100 : null;
  const type = instagramType(media);
  const notes = [];
  if (likes === null) notes.push("좋아요 미제공/비공개");
  if (comments === null) notes.push("댓글 미제공");
  if (views === null && ["릴스", "동영상"].includes(type)) notes.push("조회수 미제공");
  const caption = media.caption && media.caption.text ? media.caption.text : (media.caption_text || "");
  const code = media.code || "";
  return {
    "플랫폼": "Instagram",
    "계정": username,
    "순번": rank,
    "유형": type,
    "게시일": localDateFromUnix(media.taken_at),
    "조회수": views,
    "좋아요": likes,
    "댓글": comments,
    "참여수": engagement,
    "참여율(%)": rate,
    "제목": sanitizeText(caption).replace(/\s+/g, " ").slice(0, 120),
    "링크": code ? `https://www.instagram.com/${type === "릴스" ? "reel" : "p"}/${code}/` : "",
    "수집출처": "Instagram 로그인 웹",
    "비고": notes.join("; "),
    _time: asNumber(media.taken_at) || 0
  };
}

async function collectInstagram(ref, count, mode, verify, signal, progress) {
  const profile = await resolveInstagramProfile(ref, signal);
  progress(`${profile.username} 목록을 불러오는 중`);
  const target = count + 8;
  let feed = [], clips = [], warnings = [...(profile.warnings || [])];
  if (mode !== "reels") {
    try { feed = await instagramFeed(profile, target, signal); }
    catch (error) {
      if (mode === "feed") throw error;
      warnings.push(`프로필 피드 실패: ${safeMessage(error)}`);
    }
  }
  if (mode !== "feed") {
    try { clips = await instagramClips(profile, target, signal); }
    catch (error) {
      warnings.push(`릴스 목록 실패: ${safeMessage(error)}`);
      if (!feed.length) feed = await instagramFeed(profile, target, signal);
      clips = feed.filter(isInstagramReel);
      if (mode === "reels" && !clips.length) throw error;
    }
  }
  const merged = new Map();
  const candidates = mode === "reels" ? clips : [...feed, ...clips];
  for (const media of candidates) {
    const key = mediaIdentity(media);
    if (key && !merged.has(key)) merged.set(key, media);
  }
  let selected = [...merged.values()].sort((a, b) => (asNumber(b.taken_at) || 0) - (asNumber(a.taken_at) || 0)).slice(0, count);
  if (!selected.length) throw new Error(`${profile.username}에서 열람 가능한 콘텐츠를 찾지 못했습니다.`);
  if (verify) {
    const refreshed = [];
    for (let i = 0; i < selected.length; i++) {
      progress(`${profile.username} 수치 재확인 ${i + 1}/${selected.length}`);
      const original = selected[i];
      try {
        const detail = original.code ? await instagramMediaInfo(original.code, signal) : original;
        refreshed.push(detail);
      } catch (error) {
        warnings.push(`${original.code || i + 1} 상세 수치 확인 실패`);
        refreshed.push(original);
        if (/요청 제한/.test(safeMessage(error))) {
          refreshed.push(...selected.slice(i + 1));
          break;
        }
      }
      await sleep(420, signal);
    }
    selected = refreshed.slice(0, count);
  }
  const rows = selected.sort((a, b) => (asNumber(b.taken_at) || 0) - (asNumber(a.taken_at) || 0))
    .map((media, index) => instagramRow(media, profile.username, index + 1));
  if (warnings.length && rows[0]) rows[0]["비고"] = [rows[0]["비고"], ...warnings].filter(Boolean).join("; ");
  return rows;
}

function extractJsonObject(text, marker) {
  const markerIndex = text.indexOf(marker);
  if (markerIndex < 0) return null;
  const start = text.indexOf("{", markerIndex + marker.length);
  if (start < 0) return null;
  let depth = 0, inString = false, escaped = false;
  for (let i = start; i < text.length; i++) {
    const ch = text[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') { inString = true; continue; }
    if (ch === "{") depth++;
    else if (ch === "}") {
      depth--;
      if (depth === 0) {
        try { return JSON.parse(text.slice(start, i + 1)); } catch { return null; }
      }
    }
  }
  return null;
}

function firstObjectWithKey(root, key) {
  if (!root || typeof root !== "object") return null;
  if (Object.prototype.hasOwnProperty.call(root, key)) return root[key];
  for (const value of Object.values(root)) {
    const found = firstObjectWithKey(value, key);
    if (found !== null && found !== undefined) return found;
  }
  return null;
}

function firstValueWithKey(root, key, predicate) {
  if (!root || typeof root !== "object") return null;
  if (Object.prototype.hasOwnProperty.call(root, key) && predicate(root[key])) return root[key];
  for (const value of Object.values(root)) {
    const found = firstValueWithKey(value, key, predicate);
    if (found !== null && found !== undefined) return found;
  }
  return null;
}

function textFromRuns(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  if (value.simpleText) return value.simpleText;
  if (Array.isArray(value.runs)) return value.runs.map((r) => r.text || "").join("");
  return "";
}

function textCandidates(root, result = []) {
  if (root === null || root === undefined) return result;
  if (typeof root === "string") {
    const value = sanitizeText(root);
    if (value) result.push(value);
    return result;
  }
  if (typeof root !== "object") return result;
  for (const value of Object.values(root)) textCandidates(value, result);
  return result;
}

function extractYoutubeLikes(initialData) {
  const primary = firstObjectWithKey(initialData, "videoPrimaryInfoRenderer") ||
    firstObjectWithKey(initialData, "videoPrimaryInfoViewModel");
  if (!primary) return null;
  const areas = [
    firstObjectWithKey(primary, "likeButtonViewModel"),
    firstObjectWithKey(primary, "segmentedLikeDislikeButtonRenderer"),
    primary
  ].filter(Boolean);
  for (const area of areas) {
    for (const label of textCandidates(area)) {
      if (!/\d/.test(label) || /dislike|싫어요/i.test(label)) continue;
      if (/\blikes?\b/i.test(label) || /좋아요/.test(label)) {
        const count = parseCountText(label);
        if (count !== null) return count;
      }
    }
  }
  return null;
}

function extractYoutubeCommentCount(initialData) {
  const header = firstObjectWithKey(initialData, "commentsHeaderRenderer") ||
    firstObjectWithKey(initialData, "commentsEntryPointHeaderRenderer") ||
    firstObjectWithKey(initialData, "commentsEntryPointHeaderViewModel");
  if (!header) return null;
  const directFields = [header.countText, header.commentCount, header.commentCountText, header.headerText];
  for (const value of directFields) {
    const count = parseCountText(textFromRuns(value));
    if (count !== null) return count;
  }
  for (const label of textCandidates(header)) {
    if (/\d/.test(label) && (/comments?/i.test(label) || /댓글/.test(label))) {
      const count = parseCountText(label);
      if (count !== null) return count;
    }
  }
  return null;
}

async function youtubeText(url, signal) {
  const response = await fetchWithTimeout(url, {
    credentials: "omit",
    cache: "no-store",
    headers: { "accept-language": "en-US,en;q=0.9" },
    signal
  });
  if (!response.ok) throw new Error(`YouTube 요청 실패 (HTTP ${response.status})`);
  return { text: await response.text(), finalUrl: response.url };
}

async function youtubeApi(endpoint, params, key, signal) {
  const query = new URLSearchParams({ ...params, key });
  const response = await fetchWithTimeout(`https://www.googleapis.com/youtube/v3/${endpoint}?${query}`, { signal });
  const text = await response.text();
  let json = {};
  try { json = JSON.parse(text); } catch {}
  if (!response.ok) {
    const message = json.error && json.error.message ? json.error.message : `HTTP ${response.status}`;
    throw new Error(`YouTube API 오류: ${message}`);
  }
  return json;
}

function channelIdFromHtml(html) {
  const patterns = [
    /<meta\s+itemprop="channelId"\s+content="(UC[A-Za-z0-9_-]+)"/i,
    /"externalId":"(UC[A-Za-z0-9_-]+)"/,
    /"channelId":"(UC[A-Za-z0-9_-]+)"/
  ];
  for (const pattern of patterns) {
    const match = html.match(pattern);
    if (match) return match[1];
  }
  return null;
}

function titleFromHtml(html) {
  const match = html.match(/<meta\s+property="og:title"\s+content="([^"]*)"/i);
  return match ? sanitizeText(match[1].replace(/&amp;/g, "&").replace(/&quot;/g, '"')) : "";
}

async function resolveYoutubeChannel(ref, key, signal) {
  if (key) {
    if (ref.kind === "video") {
      const video = await youtubeApi("videos", { part: "snippet", id: ref.value }, key, signal);
      const item = (video.items || [])[0];
      if (item) return { id: item.snippet.channelId, title: sanitizeText(item.snippet.channelTitle), label: ref.raw };
    }
    if (["channelId", "handle"].includes(ref.kind)) {
      const filter = ref.kind === "channelId" ? { id: ref.value } : { forHandle: ref.value };
      const json = await youtubeApi("channels", { part: "snippet,contentDetails", ...filter }, key, signal);
      const item = (json.items || [])[0];
      if (item) return {
        id: item.id,
        title: sanitizeText(item.snippet && item.snippet.title),
        uploads: item.contentDetails && item.contentDetails.relatedPlaylists && item.contentDetails.relatedPlaylists.uploads,
        label: ref.raw
      };
    }
  }
  let url;
  if (ref.kind === "channelId") url = `https://www.youtube.com/channel/${ref.value}`;
  else if (ref.kind === "handle") url = `https://www.youtube.com/${encodeURIComponent(ref.value).replace(/%40/g, "@")}`;
  else if (ref.kind === "video") url = `https://www.youtube.com/watch?v=${encodeURIComponent(ref.value)}`;
  else url = ref.value;
  const { text, finalUrl } = await youtubeText(`${url}${url.includes("?") ? "&" : "?"}hl=en`, signal);
  const player = ref.kind === "video" ? (extractJsonObject(text, "ytInitialPlayerResponse =") || extractJsonObject(text, "var ytInitialPlayerResponse =")) : null;
  const id = (player && player.videoDetails && player.videoDetails.channelId) || channelIdFromHtml(text);
  if (!id) throw new Error(`YouTube 채널 ID를 확인하지 못했습니다: ${ref.raw}`);
  const title = sanitizeText((player && player.videoDetails && player.videoDetails.author) || titleFromHtml(text) || ref.raw);
  return { id, title, uploads: `UU${id.slice(2)}`, label: finalUrl };
}

function videoIdsFromHtml(html) {
  const result = [], seen = new Set();
  for (const match of html.matchAll(/"videoId":"([A-Za-z0-9_-]{11})"/g)) {
    if (!seen.has(match[1])) { seen.add(match[1]); result.push(match[1]); }
  }
  return result;
}

async function youtubeTypeSets(channelId, signal) {
  const sets = { shorts: new Set(), streams: new Set() };
  await Promise.all(["shorts", "streams"].map(async (tab) => {
    try {
      const { text } = await youtubeText(`https://www.youtube.com/channel/${channelId}/${tab}?hl=en`, signal);
      for (const id of videoIdsFromHtml(text)) sets[tab].add(id);
    } catch (_) {}
  }));
  return sets;
}

function youtubeKind(videoId, detail, sets) {
  if (sets.shorts.has(videoId)) return "쇼츠";
  if (sets.streams.has(videoId) || detail.liveStreamingDetails || (detail.snippet && detail.snippet.liveBroadcastContent !== "none")) return "라이브";
  return "동영상";
}

function youtubeRow(detail, account, rank, kind, source) {
  const stats = detail.statistics || {};
  const snippet = detail.snippet || {};
  const views = asNumber(stats.viewCount ?? detail.views);
  const likes = asNumber(stats.likeCount ?? detail.likes);
  const comments = asNumber(stats.commentCount ?? detail.comments);
  const engagement = likes !== null && comments !== null ? likes + comments : null;
  const rate = views && engagement !== null ? Math.round((engagement * 10000) / views) / 100 : null;
  const notes = [];
  if (likes === null) notes.push("좋아요 미제공/비공개");
  if (comments === null) notes.push("댓글 미제공/댓글 사용 중지");
  return {
    "플랫폼": "YouTube",
    "계정": sanitizeText(account),
    "순번": rank,
    "유형": kind,
    "게시일": isoDate(snippet.publishedAt || detail.published),
    "조회수": views,
    "좋아요": likes,
    "댓글": comments,
    "참여수": engagement,
    "참여율(%)": rate,
    "제목": sanitizeText(snippet.title || detail.title || ""),
    "링크": `https://www.youtube.com/watch?v=${detail.id}`,
    "수집출처": source,
    "비고": notes.join("; "),
    _time: new Date(snippet.publishedAt || detail.published || 0).getTime() || 0
  };
}

async function youtubeCandidatesNoKey(channel, count, signal) {
  const ids = [], seen = new Set();
  try {
    const { text } = await youtubeText(`https://www.youtube.com/feeds/videos.xml?channel_id=${channel.id}`, signal);
    const doc = new DOMParser().parseFromString(text, "application/xml");
    for (const entry of doc.querySelectorAll("entry")) {
      const id = (entry.getElementsByTagNameNS("*", "videoId")[0] || entry.querySelector("yt\\:videoId") || entry.querySelector("videoId"))?.textContent?.trim();
      if (id && !seen.has(id)) { seen.add(id); ids.push(id); }
    }
  } catch (_) {}
  if (ids.length < count) {
    for (const tab of ["videos", "shorts", "streams"]) {
      try {
        const { text } = await youtubeText(`https://www.youtube.com/channel/${channel.id}/${tab}?hl=en`, signal);
        for (const id of videoIdsFromHtml(text)) {
          if (!seen.has(id)) { seen.add(id); ids.push(id); }
          if (ids.length >= Math.max(count * 3, 30)) break;
        }
      } catch (_) {}
    }
  }
  return ids;
}

function findCommentData(initialData) {
  const direct = extractYoutubeCommentCount(initialData);
  if (direct !== null) return { count: direct, token: null };
  const section = firstValueWithKey(initialData, "itemSectionRenderer", (value) => value && value.sectionIdentifier === "comment-item-section");
  if (section) {
    const command = firstObjectWithKey(section, "continuationCommand");
    return { count: null, token: command && command.token };
  }
  return { count: null, token: null };
}

async function youtubeCommentsFromContinuation(html, initialData, signal) {
  const found = findCommentData(initialData || {});
  if (found.count !== null) return found.count;
  if (!found.token) return null;
  const keyMatch = html.match(/"INNERTUBE_API_KEY":"([^"]+)"/);
  const versionMatch = html.match(/"INNERTUBE_CLIENT_VERSION":"([^"]+)"/) || html.match(/"clientVersion":"(2\.[\d.]+)"/);
  if (!keyMatch || !versionMatch) return null;
  const response = await fetchWithTimeout(`https://www.youtube.com/youtubei/v1/next?key=${encodeURIComponent(keyMatch[1])}&prettyPrint=false`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-youtube-client-name": "1", "x-youtube-client-version": versionMatch[1] },
    body: JSON.stringify({
      context: { client: { hl: "en", gl: "US", clientName: "WEB", clientVersion: versionMatch[1] } },
      continuation: found.token
    }),
    signal
  });
  if (!response.ok) return null;
  const json = await response.json();
  return extractYoutubeCommentCount(json);
}

async function youtubeDetailNoKey(id, signal) {
  const { text } = await youtubeText(`https://www.youtube.com/watch?v=${id}&hl=en&gl=US`, signal);
  const player = extractJsonObject(text, "ytInitialPlayerResponse =") || extractJsonObject(text, "var ytInitialPlayerResponse =") || {};
  const initialData = extractJsonObject(text, "ytInitialData =") || extractJsonObject(text, "var ytInitialData =") || {};
  const details = player.videoDetails || {};
  const micro = player.microformat && player.microformat.playerMicroformatRenderer || {};
  let comments = null;
  try { comments = await youtubeCommentsFromContinuation(text, initialData, signal); } catch (_) {}
  return {
    id,
    title: sanitizeText(details.title || titleFromHtml(text)),
    published: micro.publishDate || micro.uploadDate || "",
    views: asNumber(details.viewCount),
    likes: extractYoutubeLikes(initialData),
    comments,
    snippet: { title: sanitizeText(details.title || titleFromHtml(text)), publishedAt: micro.publishDate || micro.uploadDate || "", liveBroadcastContent: micro.liveBroadcastDetails ? "live" : "none" },
    liveStreamingDetails: micro.liveBroadcastDetails || null
  };
}

async function collectYoutube(ref, count, key, signal, progress) {
  progress(`${ref.raw} 채널 확인 중`);
  const channel = await resolveYoutubeChannel(ref, key, signal);
  const account = sanitizeText(channel.title || ref.raw);
  const setsPromise = youtubeTypeSets(channel.id, signal);
  let details = [], source;
  if (key) {
    progress(`${account} 최근 업로드 조회 중`);
    const playlist = await youtubeApi("playlistItems", {
      part: "contentDetails,snippet",
      playlistId: channel.uploads || `UU${channel.id.slice(2)}`,
      maxResults: String(Math.min(50, Math.max(count, 10)))
    }, key, signal);
    const ids = (playlist.items || []).map((item) => item.contentDetails && item.contentDetails.videoId).filter(Boolean);
    if (!ids.length) throw new Error(`${account}의 공개 업로드를 찾지 못했습니다.`);
    const videoJson = await youtubeApi("videos", {
      part: "snippet,statistics,contentDetails,liveStreamingDetails",
      id: ids.join(",")
    }, key, signal);
    details = videoJson.items || [];
    source = "YouTube Data API";
  } else {
    const ids = await youtubeCandidatesNoKey(channel, count, signal);
    if (!ids.length) throw new Error(`${account}의 공개 업로드를 찾지 못했습니다.`);
    for (let i = 0; i < ids.length && details.length < Math.max(count, 15); i++) {
      progress(`${account} 공개 페이지 ${i + 1}/${Math.min(ids.length, Math.max(count, 15))}`);
      try { details.push(await youtubeDetailNoKey(ids[i], signal)); }
      catch (_) {}
      await sleep(220, signal);
    }
    source = "YouTube 공개 페이지 (최선값)";
  }
  const sets = await setsPromise;
  details.sort((a, b) => new Date((b.snippet && b.snippet.publishedAt) || b.published || 0) - new Date((a.snippet && a.snippet.publishedAt) || a.published || 0));
  return details.slice(0, count).map((detail, index) => youtubeRow(detail, account, index + 1, youtubeKind(detail.id, detail, sets), source));
}

function csvCell(value) {
  let text = value === null || value === undefined ? "" : sanitizeText(value);
  if (/^[=+\-@]/.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}

function rowsToCsv(rows) {
  const lines = [COLS.map(csvCell).join(",")];
  for (const row of rows) lines.push(COLS.map((col) => csvCell(row[col])).join(","));
  return `\uFEFF${lines.join("\r\n")}`;
}

const Core = {
  asNumber, parseCountText, instagramRef, youtubeRef, instagramCodeToPk,
  extractJsonObject, textFromRuns, rowsToCsv, instagramRow, youtubeRow,
  sanitizeText, builtInYoutubeKey, extractYoutubeLikes, extractYoutubeCommentCount, instagramGraphItems, instagramFeed, inputPlatform
};
if (typeof module !== "undefined" && module.exports) module.exports = Core;
if (typeof globalThis !== "undefined") globalThis.SocialMetricsCore = Core;

function initApp() {
  const $ = (id) => document.getElementById(id);
  const teamYoutubeKey = builtInYoutubeKey();
  const els = {
    linkInputs: $("linkInputs"), igMode: $("igMode"), ytApiKey: $("ytApiKey"),
    count: $("countInput"), verify: $("verifyIg"), run: $("runBtn"), cancel: $("cancelBtn"), csv: $("csvBtn"),
    clear: $("clearBtn"), toggleKey: $("toggleKeyBtn"), ytKeyStatus: $("ytKeyStatus"), spinner: $("spinner"), statusTitle: $("statusTitle"),
    statusDetail: $("statusDetail"), errorsBox: $("errorsBox"), errorsList: $("errorsList"),
    head: $("resultHead"), body: $("resultBody"), resultCount: $("resultCount")
  };

  function applyYoutubeKeyMode() {
    if (teamYoutubeKey) {
      els.ytApiKey.value = "";
      els.ytApiKey.disabled = true;
      els.ytApiKey.placeholder = "팀 공용 API가 연결되어 있습니다";
      els.toggleKey.classList.add("hidden");
      els.ytKeyStatus.textContent = "팀 공용 YouTube API 연결됨 · 팀원은 별도 설정이 필요 없습니다.";
      els.ytKeyStatus.classList.add("connected");
    } else {
      els.ytApiKey.disabled = false;
      els.ytApiKey.placeholder = "필요한 경우 API 키 입력";
      els.toggleKey.classList.remove("hidden");
      els.ytKeyStatus.textContent = "API 키가 없으면 공개 페이지 방식으로 수집합니다.";
      els.ytKeyStatus.classList.remove("connected");
    }
  }

  function setStatus(title, detail, busy = false) {
    els.statusTitle.textContent = title;
    els.statusDetail.textContent = detail || "";
    els.spinner.classList.toggle("hidden", !busy);
  }

  function showErrors() {
    els.errorsList.innerHTML = "";
    for (const error of state.errors) {
      const li = document.createElement("li");
      li.textContent = error;
      els.errorsList.appendChild(li);
    }
    els.errorsBox.classList.toggle("hidden", !state.errors.length);
  }

  function formatCell(col, value) {
    if (value === null || value === undefined || value === "") return "—";
    if (["조회수", "좋아요", "댓글", "참여수"].includes(col)) return Number(value).toLocaleString("ko-KR");
    if (col === "참여율(%)") return Number(value).toFixed(2);
    return String(value);
  }

  function renderRows() {
    els.head.innerHTML = `<tr>${COLS.map((col) => `<th>${col}</th>`).join("")}</tr>`;
    els.body.innerHTML = "";
    if (!state.rows.length) {
      els.body.innerHTML = `<tr class="empty-row"><td colspan="${COLS.length}">아직 수집된 데이터가 없습니다.</td></tr>`;
    } else {
      for (const row of state.rows) {
        const tr = document.createElement("tr");
        for (const col of COLS) {
          const td = document.createElement("td");
          if (col === "제목") td.className = "title-cell";
          if (col === "비고") td.className = "note-cell";
          if (col === "링크" && row[col]) {
            const a = document.createElement("a");
            a.href = row[col]; a.target = "_blank"; a.rel = "noreferrer"; a.textContent = "열기";
            td.appendChild(a);
          } else {
            td.textContent = formatCell(col, row[col]);
          }
          if (row[col] !== null && row[col] !== undefined) td.title = String(row[col]);
          tr.appendChild(td);
        }
        els.body.appendChild(tr);
      }
    }
    els.resultCount.textContent = `${state.rows.length}행`;
    els.csv.disabled = !state.rows.length || state.running;
  }

  async function saveSettings() {
    if (typeof chrome === "undefined" || !chrome.storage) return;
    await chrome.storage.local.set({
      linkInputs: els.linkInputs.value, igMode: els.igMode.value,
      ytApiKey: teamYoutubeKey ? "" : els.ytApiKey.value.trim(), count: Number(els.count.value), verifyIg: els.verify.checked
    });
  }

  async function loadSettings() {
    if (typeof chrome === "undefined" || !chrome.storage) return;
    const saved = await chrome.storage.local.get(["linkInputs", "igInputs", "ytInputs", "igMode", "ytApiKey", "count", "verifyIg"]);
    if (saved.linkInputs) els.linkInputs.value = saved.linkInputs;
    else {
      const migrated = [];
      for (const value of cleanLines(saved.igInputs || "")) {
        migrated.push(/^https?:\/\//i.test(value) ? value : `https://www.instagram.com/${value.replace(/^@/, "")}/`);
      }
      for (const value of cleanLines(saved.ytInputs || "")) {
        if (/^https?:\/\//i.test(value)) migrated.push(value);
        else if (/^UC[A-Za-z0-9_-]{20,}$/.test(value)) migrated.push(`https://www.youtube.com/channel/${value}`);
        else migrated.push(`https://www.youtube.com/${value.startsWith("@") ? value : `@${value}`}`);
      }
      if (migrated.length) els.linkInputs.value = [...new Set(migrated)].join("\n");
    }
    if (saved.igMode) els.igMode.value = saved.igMode;
    if (!teamYoutubeKey && saved.ytApiKey) els.ytApiKey.value = saved.ytApiKey;
    if (saved.count) els.count.value = saved.count;
    if (saved.verifyIg !== undefined) els.verify.checked = saved.verifyIg;
    applyYoutubeKeyMode();
  }

  function setRunning(running) {
    state.running = running;
    els.run.disabled = running;
    els.cancel.classList.toggle("hidden", !running);
    els.csv.disabled = running || !state.rows.length;
  }

  async function run() {
    const allLines = cleanLines(els.linkInputs.value);
    if (!allLines.length) {
      setStatus("입력이 필요합니다", "Instagram 또는 YouTube 계정을 한 개 이상 입력해 주세요.");
      return;
    }
    const igLines = [], ytLines = [], invalid = [];
    for (const line of allLines) {
      try { (inputPlatform(line) === "instagram" ? igLines : ytLines).push(line); }
      catch (error) { invalid.push(safeMessage(error)); }
    }
    if (invalid.length) {
      state.errors = invalid;
      showErrors();
      setStatus("링크를 확인해 주세요", "계정명이나 @핸들 대신 브라우저 주소창의 전체 링크를 붙여 넣어 주세요.");
      return;
    }
    const count = Math.max(1, Math.min(50, Number.parseInt(els.count.value, 10) || 10));
    els.count.value = count;
    state.rows = [];
    state.errors = [];
    state.controller = new AbortController();
    setRunning(true); renderRows(); showErrors();
    await saveSettings();
    const signal = state.controller.signal;
    const total = igLines.length + ytLines.length;
    let done = 0;
    const progress = (detail) => setStatus(`수집 중 · ${done + 1}/${total}`, detail, true);
    try {
      for (const line of igLines) {
        if (signal.aborted) break;
        try {
          const ref = instagramRef(line);
          const rows = await collectInstagram(ref, count, els.igMode.value, els.verify.checked, signal, progress);
          state.rows.push(...rows); renderRows();
        } catch (error) {
          if (error.name === "AbortError") throw error;
          state.errors.push(`Instagram · ${line} · ${safeMessage(error)}`);
        }
        done++; showErrors();
        await sleep(700, signal);
      }
      const key = teamYoutubeKey || els.ytApiKey.value.trim();
      for (const line of ytLines) {
        if (signal.aborted) break;
        try {
          const ref = youtubeRef(line);
          const rows = await collectYoutube(ref, count, key, signal, progress);
          state.rows.push(...rows); renderRows();
        } catch (error) {
          if (error.name === "AbortError") throw error;
          state.errors.push(`YouTube · ${line} · ${safeMessage(error)}`);
        }
        done++; showErrors();
        await sleep(450, signal);
      }
      setStatus("수집 완료", `${state.rows.length}행을 수집했습니다.${state.errors.length ? ` 확인 항목 ${state.errors.length}개가 있습니다.` : ""}`);
    } catch (error) {
      setStatus(error.name === "AbortError" ? "수집 중지됨" : "수집 오류", safeMessage(error));
    } finally {
      setRunning(false); renderRows(); showErrors();
      state.controller = null;
    }
  }

  els.run.addEventListener("click", run);
  els.cancel.addEventListener("click", () => state.controller && state.controller.abort());
  els.toggleKey.addEventListener("click", () => {
    if (teamYoutubeKey) return;
    const visible = els.ytApiKey.type === "text";
    els.ytApiKey.type = visible ? "password" : "text";
    els.toggleKey.textContent = visible ? "보기" : "숨김";
  });
  els.clear.addEventListener("click", async () => {
    const message = teamYoutubeKey
      ? "입력값과 저장된 설정을 모두 지울까요? 팀 공용 API 연결은 유지됩니다."
      : "입력값과 저장된 API 키를 모두 지울까요?";
    if (!confirm(message)) return;
    els.linkInputs.value = ""; els.ytApiKey.value = "";
    state.rows = []; state.errors = []; renderRows(); showErrors();
    if (chrome && chrome.storage) await chrome.storage.local.clear();
    applyYoutubeKeyMode();
    setStatus("초기화됨", "계정 링크를 입력해 주세요.");
  });
  els.csv.addEventListener("click", () => {
    if (!state.rows.length) return;
    const blob = new Blob([rowsToCsv(state.rows)], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    const stamp = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, "");
    a.download = `소셜지표_${stamp}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 3000);
  });

  renderRows();
  applyYoutubeKeyMode();
  loadSettings().catch(() => {});
}

if (typeof document !== "undefined") initApp();
