async function openApp() {
  const appUrl = chrome.runtime.getURL("app.html");
  const tabs = await chrome.tabs.query({ url: appUrl });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    if (tabs[0].windowId != null) {
      await chrome.windows.update(tabs[0].windowId, { focused: true });
    }
    return;
  }
  await chrome.tabs.create({ url: appUrl });
}

chrome.action.onClicked.addListener(() => {
  openApp().catch(() => {});
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const portalUrl = sender.tab && sender.tab.url || "";
  if (message && message.type === "OPEN_SOCIAL_METRICS" && portalUrl.startsWith("https://bruceheo0114.github.io/work_db/")) {
    openApp().then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }
  return false;
});

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") openApp().catch(() => {});
});
