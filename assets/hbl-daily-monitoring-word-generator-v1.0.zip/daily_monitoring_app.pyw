"""허벌라이프 데일리 모니터링 Word 생성기 — 실행 화면.

링크를 붙여 넣고 [보고서 만들기]를 누르면
기사 화면을 캡처해 넣은 Word 파일이 나온다.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import traceback
from datetime import date, datetime
from pathlib import Path

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

import hbl_report as hr  # noqa: E402

DEFAULT_OUTPUT = Path.home() / "Documents" / "Herbalife News Monitoring"

PLACEHOLDER = """여기에 기사 링크를 한 줄에 하나씩 붙여 넣으세요.

온라인 기사는 링크만 넣으면 화면까지 자동으로 캡처합니다.

    https://www.example.com/news/123

면 표기를 바꾸려면 링크 뒤에 붙이세요.

    https://www.example.com/news/123 | 종합 02면

지면 기사는 링크가 없으니 이렇게 적습니다.

    지면 | 매체명 | 26.08.27 | 기사 제목 | 06면

지면 기사는 이미지 자리만 비워 두니
Word 에서 스캔 이미지를 직접 넣어 주세요."""


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("허벌라이프 데일리 모니터링 Word 생성기")
        self.geometry("900x700")
        self.minsize(780, 580)

        self.output_dir = tk.StringVar(value=str(DEFAULT_OUTPUT))
        self.report_date = tk.StringVar(value=date.today().strftime("%Y-%m-%d"))
        self.capture = tk.BooleanVar(value=True)
        self.status = tk.StringVar(value="링크를 붙여 넣고 아래 버튼을 누르세요.")
        self.busy = False
        self.last_output: Path | None = None

        self._build()

    def _build(self):
        pad = {"padx": 14, "pady": 6}

        header = ttk.Frame(self)
        header.pack(fill="x", **pad)
        ttk.Label(header, text="Herbalife News Monitoring",
                  font=("맑은 고딕", 15, "bold")).pack(side="left")

        row = ttk.Frame(self)
        row.pack(fill="x", **pad)
        ttk.Label(row, text="보고서 날짜").pack(side="left")
        ttk.Entry(row, textvariable=self.report_date, width=14).pack(side="left", padx=(6, 18))
        ttk.Label(row, text="저장 위치").pack(side="left")
        ttk.Entry(row, textvariable=self.output_dir).pack(side="left", fill="x",
                                                          expand=True, padx=6)
        ttk.Button(row, text="바꾸기", command=self.pick_folder).pack(side="left")

        opt = ttk.Frame(self)
        opt.pack(fill="x", padx=14)
        ttk.Checkbutton(opt, text="기사 화면 캡처하기 (끄면 이미지 자리만 비워 둡니다 · 훨씬 빠릅니다)",
                        variable=self.capture).pack(side="left")

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, **pad)
        ttk.Label(body, text="기사 링크").pack(anchor="w")
        self.text = tk.Text(body, wrap="word", height=14, font=("맑은 고딕", 10), undo=True)
        self.text.pack(fill="both", expand=True, pady=(4, 0))
        self.text.insert("1.0", PLACEHOLDER)
        self.text.configure(fg="#888888")
        self.text.bind("<FocusIn>", self._clear_placeholder)

        log_frame = ttk.Frame(self)
        log_frame.pack(fill="both", expand=True, **pad)
        ttk.Label(log_frame, text="진행 상황").pack(anchor="w")
        self.log = tk.Text(log_frame, wrap="word", height=10, font=("맑은 고딕", 9),
                           state="disabled", background="#f7f7f7")
        self.log.pack(fill="both", expand=True, pady=(4, 0))

        footer = ttk.Frame(self)
        footer.pack(fill="x", **pad)
        ttk.Label(footer, textvariable=self.status).pack(side="left")
        self.open_button = ttk.Button(footer, text="폴더 열기", command=self.open_folder,
                                      state="disabled")
        self.open_button.pack(side="right", padx=(8, 0))
        self.run_button = ttk.Button(footer, text="보고서 만들기", command=self.run)
        self.run_button.pack(side="right")

    def _clear_placeholder(self, _event=None):
        if self.text.get("1.0", "end").strip() == PLACEHOLDER.strip():
            self.text.delete("1.0", "end")
            self.text.configure(fg="#000000")

    def pick_folder(self):
        chosen = filedialog.askdirectory(initialdir=self.output_dir.get() or str(Path.home()))
        if chosen:
            self.output_dir.set(chosen)

    def write_log(self, message: str):
        def append():
            self.log.configure(state="normal")
            self.log.insert("end", message + "\n")
            self.log.see("end")
            self.log.configure(state="disabled")
        self.after(0, append)

    def open_folder(self):
        if not self.last_output:
            return
        try:
            os.startfile(self.last_output.parent)  # noqa: S606
        except Exception:
            subprocess.Popen(["explorer", str(self.last_output.parent)])

    def run(self):
        if self.busy:
            return
        raw = self.text.get("1.0", "end").strip()
        if not raw or raw == PLACEHOLDER.strip():
            messagebox.showinfo("링크가 없습니다", "기사 링크를 먼저 붙여 넣어 주세요.")
            return
        try:
            report_day = datetime.strptime(self.report_date.get().strip(), "%Y-%m-%d").date()
        except ValueError:
            messagebox.showerror("날짜 형식", "보고서 날짜는 2026-08-28 형태로 적어 주세요.")
            return

        self.busy = True
        self.run_button.configure(state="disabled")
        self.open_button.configure(state="disabled")
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        if self.capture.get():
            self.write_log("기사 하나당 30~60초쯤 걸립니다. 창을 닫지 말고 기다려 주세요.")
            self.write_log("")
        self.status.set("시작합니다...")

        threading.Thread(target=self._work, args=(raw, report_day), daemon=True).start()

    def _work(self, raw: str, report_day: date):
        try:
            def progress(index, total, url, phase):
                self.write_log(f"[{index}/{total}] {phase} · {url[:64]}")
                self.after(0, lambda: self.status.set(f"{phase} {index}/{total}"))

            path, items = hr.generate(raw, report_day, Path(self.output_dir.get()),
                                      progress=progress, capture=self.capture.get())
            self.last_output = path

            self.write_log("")
            self.write_log(f"만들었습니다: {path.name}")
            self.write_log("")
            for number, item in enumerate(items, start=1):
                shots = f"캡처 {len(item.captures)}장" if item.captures else "이미지 없음"
                self.write_log(f"  {number}. {item.publication} · {item.page} · {shots}")
                self.write_log(f"     {item.title[:60]}")
                if item.error:
                    self.write_log(f"     읽기 실패: {item.error}")
                elif item.capture_error:
                    self.write_log(f"     {item.capture_error[:80]}")

            missing = [i for i in items if not i.captures]
            if missing:
                self.write_log("")
                self.write_log(f"이미지가 빈 기사 {len(missing)}건 — Word 에서 직접 넣어 주세요.")
            self.write_log("")
            self.write_log("표지 목록과 캡처를 확인하고 보내세요.")

            self.after(0, lambda: self.status.set(f"완료 · {path.name}"))
            self.after(0, lambda: self.open_button.configure(state="normal"))
        except Exception as exc:
            self.write_log(traceback.format_exc())
            self.after(0, lambda: self.status.set("실패했습니다."))
            self.after(0, lambda: messagebox.showerror("만들지 못했습니다", str(exc)))
        finally:
            self.busy = False
            self.after(0, lambda: self.run_button.configure(state="normal"))


if __name__ == "__main__":
    App().mainloop()
