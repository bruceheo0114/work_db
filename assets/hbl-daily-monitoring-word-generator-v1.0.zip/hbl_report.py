"""허벌라이프 데일리 모니터링 Word 생성기.

기사 링크를 붙여 넣으면 기사를 읽어와 화면을 캡처하고
`Herbalife News Monitoring_MMDD.docx` 를 만든다.

기사 수집·본문 추출·화면 캡처는 `article_core`(바이탈뷰티 생성기와 같은 엔진)를 쓴다.
이 파일은 허벌라이프 고유의 문서 구조만 담당한다.

문서 구조는 원본 보고서의 표를 그대로 복제해서 채운다.
표를 새로 그리지 않으므로 글꼴·색·테두리·열 너비가 원본과 어긋나지 않는다.
"""
from __future__ import annotations

import copy
import re
import shutil
import tempfile
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Emu, Inches, Pt

import article_core as core

BASE_DIR = Path(__file__).resolve().parent
REFERENCE_DOCX = BASE_DIR / "assets" / "reference_hbl.docx"

# 표지 Keyword 줄. 원본 보고서에서 그대로 가져왔다.
OWN_KEYWORD_LINE = (
    "Keyword: 허벌라이프, Herbalife, 루이스 이그나로, 뉴트리셔널 쉐이크 믹스, "
    "뉴트리션 클럽, Healthy Meal 쉐이크, 건강한 식사 쉐이크, 포뮬라1, 허벌라이프 알로에겔"
)
COMPETITOR_KEYWORD_LINE = (
    "Keyword: 암웨이, 뉴트리라이트, 뉴스킨, 애터미, 아티스트리, 유니시티, 유사나, 정관장, "
    "GNC, 종근당, 멜라루카, 하이리빙, 아모레퍼시픽 바이탈뷰티, CJ제일제당 건강기능식품, "
    "코오롱 제약+스포츠 뉴트리션, 피엠인터내셔널, 독일PM, 셀렉스, 하이뮨"
)
INDUSTRY_KEYWORD_LINE = (
    "Keyword: 건강기능식품, 건강보조식품, 다이어트 식품 논란, 다이어트 보조, 다이어트 식품, "
    "비만+식사 대용, 다이어트+영양소, 네트워크 마케팅, 다단계, 직접판매, 아침식사, 간단한 아침, "
    "아침대용, 식사대용, 식품 이물질, 비타민 논란, 식약처, 스포츠 뉴트리션, 단백질 보충제, "
    "프로틴, 체중조절/감량, 단백질쉐이크, 테라젠이텍스, 단백질 시장, 피크노제놀"
)

BRAND_KEYWORDS = [
    "허벌라이프", "Herbalife", "루이스 이그나로", "뉴트리셔널 쉐이크 믹스",
    "뉴트리션 클럽", "Healthy Meal 쉐이크", "건강한 식사 쉐이크",
    "포뮬라1", "포뮬러1", "허벌라이프 알로에겔",
]

COMPETITOR_KEYWORDS = [
    "암웨이", "뉴트리라이트", "뉴스킨", "애터미", "아티스트리", "유니시티", "유사나",
    "정관장", "GNC", "종근당", "멜라루카", "하이리빙", "바이탈뷰티", "CJ제일제당",
    "CJ웰케어", "코오롱", "피엠인터내셔널", "독일PM", "셀렉스", "하이뮨", "한국콜마",
    "콜마BNH", "고려은단",
]

INDUSTRY_KEYWORDS = [
    "건강기능식품", "건강보조식품", "건기식", "다이어트", "네트워크 마케팅", "다단계",
    "직접판매", "아침식사", "아침대용", "식사대용", "식품 이물질", "비타민", "식약처",
    "스포츠 뉴트리션", "단백질", "프로틴", "체중조절", "체중감량", "피크노제놀", "웰니스",
]

# 업계 섹션 안의 소구분. 원본 보고서에 나오는 순서다.
INDUSTRY_BRAND = "건강기능식품/브랜드"
INDUSTRY_TRADE = "건강/업계"

# 특정 제품·브랜드 출시 기사인지 가르는 말들.
BRAND_LAUNCH_HINTS = ["출시", "선보여", "론칭", "리뉴얼", "신제품", "출시했다", "공개"]

SECTIONS = [
    ("own", None, OWN_KEYWORD_LINE),
    ("competitor", "Competitor News", COMPETITOR_KEYWORD_LINE),
    ("industry", "Industry News", INDUSTRY_KEYWORD_LINE),
]

MAJOR_MARKERS = {
    "자사": "own", "herbalife": "own", "허벌라이프": "own",
    "경쟁사": "competitor", "competitor": "competitor",
    "업계": "industry", "industry": "industry",
}

SUBSECTION_MARKERS = {
    "브랜드": INDUSTRY_BRAND,
    "건강기능식품/브랜드": INDUSTRY_BRAND,
    "업계": INDUSTRY_TRADE,
    "건강/업계": INDUSTRY_TRADE,
}


def classify(text: str) -> str:
    """기사 본문을 보고 자사·경쟁사·업계를 고른다."""
    lowered = text.lower()

    def hit(words):
        return any(w.lower() in lowered for w in words)

    if hit(BRAND_KEYWORDS):
        return "own"
    if hit(COMPETITOR_KEYWORDS):
        return "competitor"
    return "industry"


def industry_subsection(title: str, body: str) -> str:
    """업계 기사를 브랜드 소식과 업계 동향으로 나눈다. 초안이다."""
    haystack = f"{title} {body[:400]}"
    if any(hint in haystack for hint in BRAND_LAUNCH_HINTS):
        return INDUSTRY_BRAND
    return INDUSTRY_TRADE

# 캡처 이미지를 문서에 넣을 때 쓰는 가로 폭(A4 · 좌우 여백 0.5인치 기준).
IMAGE_WIDTH = Inches(7.27)
# 한 장이 한 쪽을 넘지 않도록 하는 세로 한계(A4 · 위아래 여백 0.5인치 기준).
MAX_IMAGE_HEIGHT = 10.4
# 기사 카드 표가 차지하는 높이. 원본에서 첫 이미지가 y=193pt 부터 시작한다.
CARD_TABLE_HEIGHT = 2.2
# 카드 표와 같은 쪽에 들어가야 하는 첫 이미지의 세로 한계.
FIRST_IMAGE_MAX_HEIGHT = MAX_IMAGE_HEIGHT - CARD_TABLE_HEIGHT


def _fit_width(image_path: Path, max_height: float = MAX_IMAGE_HEIGHT):
    """이미지가 정해진 높이 안에 들어가도록 가로 폭을 정한다.

    캡처는 세로로 긴 편이라 폭을 최대로 주면 쪽을 넘어가 어정쩡하게 잘린다.
    첫 장은 카드 표와 같은 쪽에 들어가야 하므로 더 낮은 한계를 쓴다.
    """
    try:
        from PIL import Image

        with Image.open(image_path) as image:
            width_px, height_px = image.size
    except Exception:
        return IMAGE_WIDTH
    if not width_px or not height_px:
        return IMAGE_WIDTH
    ratio = height_px / width_px
    widest = IMAGE_WIDTH.inches
    if widest * ratio > max_height:
        widest = max_height / ratio
    return Inches(round(widest, 2))


@dataclass
class HblLink:
    url: str = ""
    page: str = "Online"
    circulation: str = "N/A"
    # 지면 기사처럼 URL 이 없는 건은 아래 값을 직접 채워 쓴다.
    manual_title: str = ""
    manual_publication: str = ""
    manual_date: str = ""
    major: str | None = None
    subsection: str | None = None


@dataclass
class HblItem:
    url: str
    title: str
    publication: str
    article_date: str
    article_date_raw: str
    page: str
    circulation: str
    major: str = "industry"
    subsection: str | None = None
    captures: list[Path] = field(default_factory=list)
    error: str = ""
    capture_error: str = ""


def parse_input(raw: str) -> list[HblLink]:
    """링크 입력을 읽는다.

    한 줄에 링크 하나.
    지면 기사는 링크 대신 `지면 | 매체명 | 26.08.27 | 제목 | 06면` 형태로 적는다.
    온라인 기사도 링크 뒤에 `| 면표기` 를 붙여 Page 값을 바꿀 수 있다.
    """
    links: list[HblLink] = []
    seen: set[str] = set()
    major: str | None = None
    subsection: str | None = None

    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue

        if "http" not in line:
            marker = re.sub(r"[\[\]#:*]", "", line).strip().lower()
            if marker in MAJOR_MARKERS:
                major = MAJOR_MARKERS[marker]
                subsection = None
                continue
            if marker in SUBSECTION_MARKERS:
                major = "industry"
                subsection = SUBSECTION_MARKERS[marker]
                continue

        if line.startswith(("지면", "print", "Print")):
            parts = [p.strip() for p in line.split("|")]
            links.append(HblLink(
                url="",
                page=parts[4] if len(parts) > 4 else "",
                manual_publication=parts[1] if len(parts) > 1 else "",
                manual_date=parts[2] if len(parts) > 2 else "",
                manual_title=parts[3] if len(parts) > 3 else "",
                major=major,
                subsection=subsection,
            ))
            continue

        match = re.search(r"https?://[^\s<>\"'|]+", line)
        if not match:
            continue
        url = core._sanitize_url(match.group(0))
        if not url or url in seen:
            continue
        seen.add(url)

        page = "Online"
        tail = line[match.end():]
        extra = [p.strip() for p in tail.split("|") if p.strip()]
        if extra:
            page = extra[0]
        links.append(HblLink(url=url, page=page, major=major, subsection=subsection))
    return links


def _english_date(value: date) -> str:
    return f"{value:%B} {value.day}, {value.year}"


def _short_date(text: str) -> str:
    """`2026-08-27` 이나 `26.08.27` 를 `August 27, 2026` 으로 바꾼다."""
    text = (text or "").strip()
    for fmt in ("%Y-%m-%d", "%y.%m.%d", "%Y.%m.%d", "%Y/%m/%d"):
        try:
            return _english_date(datetime.strptime(text, fmt).date())
        except ValueError:
            continue
    return text


def _dotted_date(text: str) -> str:
    """표지 표에 쓰는 `26.08.27` 형태로 바꾼다."""
    text = (text or "").strip()
    for fmt in ("%Y-%m-%d", "%y.%m.%d", "%Y.%m.%d", "%Y/%m/%d"):
        try:
            return datetime.strptime(text, fmt).date().strftime("%y.%m.%d")
        except ValueError:
            continue
    return text


def _tidy(title: str, publication: str):
    """제목 앞뒤에 붙은 매체명을 떼고, 매체명이 도메인으로 잡힌 경우를 바로잡는다.

    일부 매체는 og:site_name 이 없어 매체명이 `goodmorningvietnam.co.kr` 처럼
    도메인으로 잡힌다. 그럴 때 제목 앞 `[굿모닝베트남미디어]` 같은 표기를 매체명으로 쓴다.
    """
    title = (title or "").strip()
    publication = (publication or "").strip()

    looks_like_domain = bool(re.match(r"^[\w.-]+\.(kr|com|net|co\.kr|org)$", publication, re.I))
    leading = re.match(r"^\[\s*([^\]]{2,20})\s*\]\s*(.+)$", title)
    if looks_like_domain and leading:
        publication = leading.group(1).strip()

    names = {publication, publication.split("(")[0].strip()}
    names.discard("")
    for name in names:
        title = re.sub(r"\s*[-–—|:·]\s*" + re.escape(name) + r"\s*$", "", title).strip()
        title = re.sub(r"^\[\s*" + re.escape(name) + r"\s*\]\s*", "", title).strip()
    # `[굿모닝베트남미디어]` 처럼 매체명이 조금 다른 형태로 앞에 붙은 것도 떼어낸다.
    if publication:
        stem = publication[:4]
        title = re.sub(r"^\[\s*" + re.escape(stem) + r"[^\]]{0,12}\]\s*", "", title).strip()
    return title, publication


def collect(links, report_day: date, progress=None, temp_dir: Path | None = None,
            capture: bool = True):
    items: list[HblItem] = []
    scratch = Path(temp_dir) if temp_dir else Path(tempfile.mkdtemp(prefix="hbl_"))
    scratch.mkdir(parents=True, exist_ok=True)
    total = len(links)

    for index, link in enumerate(links, start=1):
        if not link.url:
            items.append(HblItem(
                url="",
                title=link.manual_title or "(제목을 입력하세요)",
                publication=link.manual_publication or "",
                article_date=_short_date(link.manual_date),
                article_date_raw=link.manual_date,
                page=link.page or "",
                circulation=link.circulation,
                major=link.major or classify(link.manual_title or ""),
                subsection=link.subsection or (industry_subsection(link.manual_title or "", "")
                                              if not link.major else None),
                captures=[],
                capture_error="지면 기사입니다. 스캔 이미지를 직접 넣어 주세요.",
            ))
            continue

        if progress:
            progress(index, total, link.url, "기사 읽는 중")
        article = core.fetch_article(
            core.InputLink(url=link.url),
            brand_keywords=BRAND_KEYWORDS,
            competitor_keywords=[],
            temp_dir=scratch,
        )

        captures: list[Path] = []
        if capture and not article.error:
            if progress:
                progress(index, total, link.url, "화면 캡처 중")
            captures = core.capture_own_article(article, scratch, index, BRAND_KEYWORDS)

        title, publication = _tidy(article.title or "", article.publication or "")
        haystack = " ".join([title, article.description or "", article.body or ""])
        major = link.major or classify(haystack)
        subsection = link.subsection
        if major == "industry" and not subsection:
            subsection = industry_subsection(title, article.body or "")
        items.append(HblItem(
            url=article.final_url or link.url,
            title=title or "(제목을 읽지 못했습니다)",
            publication=publication,
            article_date=_short_date(article.published_date),
            article_date_raw=article.published_date or "",
            page=link.page or "Online",
            circulation=link.circulation,
            major=major,
            subsection=subsection,
            captures=captures,
            error=article.error,
            capture_error=article.capture_error,
        ))
    return items


# ── 문서 만들기 ────────────────────────────────────────────────

def _first_run_props(paragraph, prefer_link: bool = False):
    """문단에서 글자 서식(rPr)을 하나 찾아 둔다.

    링크를 넣을 때는 하이퍼링크 안쪽 run 을 먼저 본다.
    링크 색과 밑줄이 거기(rStyle)에 들어 있어서, 바깥 일반 run 서식을 쓰면
    링크가 검은 맨글자로 나온다.
    """
    sources = []
    if prefer_link:
        sources.append(paragraph._p.findall(qn("w:hyperlink")))
        sources.append([paragraph._p])
    else:
        sources.append([paragraph._p])
        sources.append(paragraph._p.findall(qn("w:hyperlink")))
    for group in sources:
        for holder in group:
            for run in holder.findall(qn("w:r")):
                r_pr = run.find(qn("w:rPr"))
                if r_pr is not None:
                    return copy.deepcopy(r_pr)
    return None


def _hyperlink_style_id(doc) -> str | None:
    """문서에 정의된 하이퍼링크 문자 스타일의 id 를 찾는다."""
    for style in doc.styles.element.findall(qn("w:style")):
        if style.get(qn("w:type")) != "character":
            continue
        name = style.find(qn("w:name"))
        if name is not None and name.get(qn("w:val")) == "Hyperlink":
            return style.get(qn("w:styleId"))
    return None


def _ensure_link_style(r_pr, style_id: str | None):
    """링크 서식에 하이퍼링크 스타일이 없으면 붙여 준다."""
    if not style_id:
        return r_pr
    if r_pr is None:
        r_pr = OxmlElement("w:rPr")
    if r_pr.find(qn("w:rStyle")) is None:
        node = OxmlElement("w:rStyle")
        node.set(qn("w:val"), style_id)
        r_pr.insert(0, node)
    return r_pr


def _is_tab_run(element) -> bool:
    """탭만 들어 있는 run 인지. 이런 run 은 글자를 오른쪽으로 미는 장치다."""
    return (element.tag == qn("w:r")
            and element.find(qn("w:tab")) is not None
            and element.find(qn("w:t")) is None)


def _clear_paragraph(paragraph):
    """문단에서 글자와 링크만 비운다.

    탭 전용 run 은 남긴다. 원본 표는 오른쪽 탭 정지로 날짜를 밀어내는데,
    이걸 같이 지우면 날짜가 왼쪽에 붙어 배치가 무너진다.
    """
    for child in list(paragraph._p):
        if _is_tab_run(child):
            continue
        if child.tag in (qn("w:r"), qn("w:hyperlink")):
            paragraph._p.remove(child)


def _make_run(text: str, r_pr, drop_size: bool = False):
    run = OxmlElement("w:r")
    if r_pr is not None:
        props = copy.deepcopy(r_pr)
        if drop_size:
            # 원본은 행마다 글자 크기가 제각각(6pt·9pt)이라 그대로 물려받으면
            # 헤드라인이 깨알같이 작아진다. 크기 지정을 빼고 기본값을 쓴다.
            for tag in ("w:sz", "w:szCs"):
                node = props.find(qn(tag))
                if node is not None:
                    props.remove(node)
        run.append(props)
    node = OxmlElement("w:t")
    node.text = text
    node.set(qn("xml:space"), "preserve")
    run.append(node)
    return run


def _cell_text(cell, text: str, drop_size: bool = False):
    """셀 글자를 바꾼다. 원래 서식과 탭 배치는 유지하고 링크는 지운다."""
    paragraphs = cell.paragraphs
    target = paragraphs[0]
    r_pr = _first_run_props(target)
    _clear_paragraph(target)
    target._p.append(_make_run(text, r_pr, drop_size))

    for leftover in paragraphs[1:]:
        leftover._p.getparent().remove(leftover._p)


def _cell_link(cell, text: str, url: str, drop_size: bool = False, style_id: str | None = None):
    """셀에 링크가 걸린 글자를 넣는다. 원본 표지처럼 제목이 기사로 연결된다."""
    if not url:
        _cell_text(cell, text)
        return

    paragraphs = cell.paragraphs
    target = paragraphs[0]
    r_pr = _ensure_link_style(_first_run_props(target, prefer_link=True), style_id)
    _clear_paragraph(target)

    rel_id = cell.part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), rel_id)
    hyperlink.append(_make_run(text, r_pr, drop_size))
    target._p.append(hyperlink)

    for leftover in paragraphs[1:]:
        leftover._p.getparent().remove(leftover._p)


def _row_cells(row):
    """가로 병합을 감안해 실제 셀만 왼쪽부터 돌려준다."""
    seen = []
    out = []
    for cell in row.cells:
        if cell._tc in seen:
            continue
        seen.append(cell._tc)
        out.append(cell)
    return out


def build_docx(items, report_day: date, output_path: Path) -> Path:
    shutil.copyfile(REFERENCE_DOCX, output_path)
    doc = Document(str(output_path))

    cover_template = copy.deepcopy(doc.tables[0]._tbl)
    card_template = copy.deepcopy(doc.tables[1]._tbl)
    core._clear_document_body(doc)

    body = doc.element.body
    report_label = _english_date(report_day)
    link_style = _hyperlink_style_id(doc)

    # 본문 요소는 반드시 sectPr(구역 정의) 앞에 와야 한다.
    # body.append() 를 쓰면 sectPr 뒤에 붙어 문서 구조가 어긋난다.
    sect_pr = body.find(qn("w:sectPr"))

    def place(element):
        if sect_pr is not None:
            sect_pr.addprevious(element)
        else:
            body.append(element)

    def blank_paragraph():
        paragraph = OxmlElement("w:p")
        place(paragraph)
        return paragraph

    def page_break():
        """쪽을 넘긴다.

        쪽 넘김을 담은 문단은 넘어간 쪽 맨 위에 빈 줄로 남는다.
        그 한 줄 때문에 다음 기사 묶음이 통째로 밀려 빈 쪽이 생기므로,
        글자 크기와 줄 간격을 최소로 줘서 자리를 차지하지 않게 한다.
        """
        paragraph = OxmlElement("w:p")

        p_pr = OxmlElement("w:pPr")
        spacing = OxmlElement("w:spacing")
        spacing.set(qn("w:before"), "0")
        spacing.set(qn("w:after"), "0")
        spacing.set(qn("w:line"), "20")
        spacing.set(qn("w:lineRule"), "exact")
        p_pr.append(spacing)
        p_run_pr = OxmlElement("w:rPr")
        size = OxmlElement("w:sz")
        size.set(qn("w:val"), "2")
        p_run_pr.append(size)
        p_pr.append(p_run_pr)
        paragraph.append(p_pr)

        run = OxmlElement("w:r")
        r_pr = OxmlElement("w:rPr")
        run_size = OxmlElement("w:sz")
        run_size.set(qn("w:val"), "2")
        r_pr.append(run_size)
        run.append(r_pr)
        br = OxmlElement("w:br")
        br.set(qn("w:type"), "page")
        run.append(br)
        paragraph.append(run)
        place(paragraph)

    def picture(image_path, first: bool = False):
        paragraph = doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        # 원본 보고서의 이미지 문단은 가운데 정렬에 문단 뒤 간격이 0이다.
        paragraph.paragraph_format.space_after = Pt(0)
        limit = FIRST_IMAGE_MAX_HEIGHT if first else MAX_IMAGE_HEIGHT
        paragraph.add_run().add_picture(str(image_path),
                                        width=_fit_width(image_path, limit))
        # add_paragraph 는 이미 sectPr 앞에 넣어 주므로 자리를 옮길 필요가 없다.
        return paragraph

    # ── 표지 ────────────────────────────────────────────────
    place(cover_template)
    cover = doc.tables[0]
    rows = cover.rows
    _cell_text(_row_cells(rows[2])[0], f"News Clipping List ({report_label})")

    # 레퍼런스에 담아 둔 틀들. 순서는 mkref 에서 정한 대로다.
    keyword_template = copy.deepcopy(rows[4]._tr)
    data_template = copy.deepcopy(rows[5]._tr)
    section_template = copy.deepcopy(rows[6]._tr)
    subsection_template = copy.deepcopy(rows[7]._tr)

    # 머리행(3행)까지 남기고 나머지 틀 행은 걷어낸다.
    for row in rows[4:]:
        row._tr.getparent().remove(row._tr)

    def add_row(template, values, drop_size_last=False):
        new_tr = copy.deepcopy(template)
        cover._tbl.append(new_tr)
        cells = _row_cells(cover.rows[-1])
        for index, value in enumerate(values):
            if index >= len(cells):
                break
            last = index == len(values) - 1
            _cell_text(cells[index], value, drop_size=drop_size_last and last)
        return cells

    ordered: list[HblItem] = []
    number = 0
    for key, section_title, keyword_line in SECTIONS:
        group = [i for i in items if i.major == key]
        if not group:
            continue
        if section_title:
            add_row(section_template, [section_title])
        add_row(keyword_template, [keyword_line])

        if key == "industry":
            buckets = [(INDUSTRY_BRAND, [i for i in group if i.subsection == INDUSTRY_BRAND]),
                       (INDUSTRY_TRADE, [i for i in group if i.subsection != INDUSTRY_BRAND])]
        else:
            buckets = [(None, group)]

        for bucket_title, bucket in buckets:
            if not bucket:
                continue
            if bucket_title:
                add_row(subsection_template, [bucket_title])
            for item in bucket:
                number += 1
                ordered.append(item)
                cells = add_row(data_template, [
                    str(number), item.publication,
                    _dotted_date(item.article_date_raw), item.title,
                ], drop_size_last=True)
                if len(cells) > 3:
                    _cell_link(cells[3], item.title, item.url, drop_size=True,
                               style_id=link_style)

    # 표지 다음은 쪽을 넘긴다. 원본과 같은 배치다.
    page_break()

    # ── 기사별 카드 ── 표지 순서를 그대로 따른다.
    items = ordered
    for position, item in enumerate(items):
        card = copy.deepcopy(card_template)
        place(card)
        table = doc.tables[-1]
        head_cells = _row_cells(table.rows[0])
        _cell_text(head_cells[0], "News Clipping")
        if len(head_cells) > 1:
            _cell_text(head_cells[1], report_label)

        for row, label, value in (
            (table.rows[1], "Date", item.article_date),
            (table.rows[2], "Publication", item.publication),
            (table.rows[3], "Page", item.page),
            (table.rows[4], "Circulation", item.circulation),
        ):
            cells = _row_cells(row)
            _cell_text(cells[0], label)
            if len(cells) > 2:
                _cell_text(cells[2], value)

        # 원본은 카드 표 바로 아래에 빈 줄 하나를 두고 기사 이미지를 붙인다.
        # 이 빈 줄에 keepNext 를 걸어 표와 첫 캡처가 서로 다른 쪽으로 갈라지지 않게 한다.
        anchor = blank_paragraph()
        p_pr = OxmlElement("w:pPr")
        p_pr.append(OxmlElement("w:keepNext"))
        anchor.insert(0, p_pr)

        if item.captures:
            for order, image_path in enumerate(item.captures):
                picture(image_path, first=(order == 0))
        else:
            note = doc.add_paragraph()
            note.alignment = WD_ALIGN_PARAGRAPH.CENTER
            reason = item.capture_error or item.error or "화면을 가져오지 못했습니다."
            run = note.add_run(f"[ 기사 이미지를 여기에 넣어 주세요 — {reason} ]")
            core._set_run_font(run, size=9, color="808080")

        if position < len(items) - 1:
            # 쪽 넘김 앞에 빈 줄을 두면 그 줄이 다음 쪽으로 밀려 빈 쪽이 하나 생긴다.
            # 쪽 넘김만 넣어 기사 사이를 끊는다.
            page_break()

    doc.save(str(output_path))
    return output_path


def output_filename(report_day: date) -> str:
    return f"Herbalife News Monitoring_{report_day:%m%d}.docx"


def generate(raw_links: str, report_day: date, output_dir: Path, progress=None,
             capture: bool = True):
    links = parse_input(raw_links)
    if not links:
        raise ValueError("링크를 찾지 못했습니다. http로 시작하는 주소를 넣어 주세요.")
    items = collect(links, report_day, progress=progress, capture=capture)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = core._select_output_path(output_dir / output_filename(report_day))
    build_docx(items, report_day, path)
    return path, items
