from __future__ import annotations

import hashlib
import json
import secrets
import socket
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from uuid import uuid4

from generator import generate_report


APP_DIR = Path(__file__).resolve().parent
REFERENCE_PATH = APP_DIR / "assets" / "reference.docx"
DEFAULT_OUTPUT = Path.home() / "Documents" / "Daily Monitoring Output"
AUTH_TOKEN = secrets.token_urlsafe(18)
JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()
SERVER: ThreadingHTTPServer | None = None
APP_PORT = 53183


def _compute_app_version() -> str:
    # A stale server left running from a previous version of this app would
    # otherwise keep serving old in-memory code forever, silently ignoring any
    # update to these files - a new launch detects that mismatch and restarts it.
    hasher = hashlib.sha256()
    for name in ("daily_monitoring_app.pyw", "generator.py"):
        try:
            hasher.update((APP_DIR / name).read_bytes())
        except OSError:
            pass
    return hasher.hexdigest()[:16]


APP_VERSION = _compute_app_version()


HTML_TEMPLATE = r"""<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>바이탈뷰티 데일리 모니터링 Word 생성기</title>
  <style>
    :root{--navy:#111;--ink:#202020;--muted:#686868;--line:#d7d7d7;--bg:#f4f4f2;--card:#fff;--blue:#e8f1f2;--red:#b42318;--green:#117a45}
    *{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--ink);font-family:"Malgun Gothic","맑은 고딕",Arial,sans-serif}
    .wrap{max-width:1040px;margin:0 auto;padding:34px 28px 60px}.brand{height:8px;background:var(--navy);border-radius:8px 8px 0 0}
    h1{margin:18px 0 4px;color:var(--navy);font-size:30px;line-height:1.25}.lead{margin:0 0 22px;color:var(--muted);font-size:14px}
    .card{background:var(--card);border:1px solid var(--line);border-radius:13px;padding:20px;box-shadow:0 8px 24px rgba(31,51,73,.06);margin-bottom:14px}
    .card h2{font-size:16px;color:var(--navy);margin:0 0 15px}.grid{display:grid;grid-template-columns:130px 1fr 130px 1fr;gap:11px 14px;align-items:center}
    label{font-size:13px;font-weight:700}.help{font-size:12px;color:var(--muted);font-weight:400;line-height:1.55}
    input,textarea{width:100%;border:1px solid #c7d0da;border-radius:7px;padding:10px 11px;font:inherit;color:var(--ink);background:#fff}
    input:focus,textarea:focus{outline:3px solid rgba(42,120,134,.14);border-color:#2a7886}textarea{min-height:245px;resize:vertical;line-height:1.55}
    .links-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px}.count{font-size:12px;color:var(--muted);background:var(--blue);padding:4px 9px;border-radius:99px}
    .check{display:flex;gap:9px;align-items:center;margin-top:12px}.check input{width:auto}.check label{font-weight:400}
    .actions{display:flex;align-items:center;gap:10px;justify-content:flex-end;margin-top:14px}.button{border:0;border-radius:8px;padding:11px 17px;font:inherit;font-weight:700;cursor:pointer}
    .primary{background:var(--navy);color:#fff}.primary:hover{background:#2d2d2d}.secondary{background:#e8eded;color:#273737}.danger{background:#fff1f0;color:var(--red);border:1px solid #f1c0bb}
    .button:disabled{opacity:.55;cursor:default}.status{display:none;margin-top:15px;border-radius:9px;padding:13px 14px;background:#f7f9fc;border:1px solid var(--line);font-size:13px;white-space:pre-wrap}
    .status.show{display:block}.status.error{background:#fff4f2;color:var(--red);border-color:#f3c5c0}.status.success{background:#effaf4;color:var(--green);border-color:#bce5ce}
    .bar{display:none;height:4px;background:#dfe5e5;border-radius:99px;overflow:hidden;margin-top:12px}.bar.show{display:block}.bar:before{content:"";display:block;width:35%;height:100%;background:#2a7886;animation:move 1.1s infinite ease-in-out}@keyframes move{from{transform:translateX(-100%)}to{transform:translateX(390%)}}
    .output-grid{display:grid;grid-template-columns:130px 1fr;gap:12px;align-items:center}.footer{display:flex;justify-content:space-between;align-items:center;color:var(--muted);font-size:12px;margin-top:12px}
    @media(max-width:760px){.wrap{padding:20px 14px 40px}.grid{grid-template-columns:1fr}.output-grid{grid-template-columns:1fr}.actions{flex-wrap:wrap}.button{flex:1}h1{font-size:24px}}
  </style>
</head>
<body>
  <main class="wrap">
    <div class="brand"></div>
    <h1>바이탈뷰티 데일리 모니터링 Word 생성기</h1>
    <p class="lead">기사 링크를 붙여 넣으면 자사·경쟁사·성분·업계로 나누고, 자사 기사는 전문 캡처 이미지까지 포함한 Word 보고서를 만듭니다.</p>
    <section class="card">
      <h2>보고서 설정</h2>
      <div class="grid">
        <label for="client">보고서 코드</label><input id="client" value="VB">
        <label for="reportDate">보고서 날짜</label><input id="reportDate" type="date" value="__TODAY__">
        <label for="brand">자사 키워드</label><input id="brand" value="바이탈뷰티, 메타그린, 슈퍼콜라겐, 슈퍼콜라겐PDRN, 슈퍼레티놀, 슈퍼시카, 굿슬립가바, 우먼밸런스, 명작수, 녹차에서온유산균, 에너지샷">
        <label for="competitors">경쟁사 키워드</label><input id="competitors" value="비에날씬, 콜레올로지, 스키니랩, 맥스컷, 탄탄슬리밍, 딥트, 영라뉴, 에스더포뮬러, 뉴트리, 뉴트리원, 오니스트, 아일로, 비거너리, 오쏘몰, 세노비스, 센트룸, 아임비타, 고려은단">
      </div>
    </section>
    <section class="card">
      <div class="links-head"><h2 style="margin:0">기사 링크</h2><span class="count" id="count">0개</span></div>
      <p class="help">링크만 한 줄에 하나씩 넣어도 키워드로 자동 분류됩니다. 분류를 고정하려면 링크 위에 <b>[자사]</b>, <b>[경쟁사]</b>, <b>[성분]</b>, <b>[업계]</b>라고 적으세요. 자사 기사만 전문 캡처 이미지가 붙고, 나머지는 요약표의 원문 링크로 연결됩니다.</p>
      <textarea id="links" placeholder="https://news.example.com/article-1&#10;https://news.example.com/article-2"></textarea>
    </section>
    <section class="card">
      <h2>저장 위치</h2>
      <div class="output-grid"><label for="output">결과 폴더</label><input id="output" value="__DEFAULT_OUTPUT__"></div>
      <div id="connWarning" style="display:none;margin:0 0 14px;padding:12px 14px;border-radius:10px;background:#fdecea;border:1px solid #f3c3bd;color:#b42318;font-size:13px;line-height:1.5">서버 연결이 끊어졌습니다. 이 창을 닫고 "데일리 모니터링 생성기 실행.cmd"를 다시 실행해 주세요.</div>
      <div class="bar" id="bar"></div><div class="status" id="status"></div>
      <div class="actions"><button class="button secondary" id="openBtn" style="display:none">완성 파일 위치 열기</button><button class="button primary" id="generateBtn">Word 보고서 만들기</button></div>
    </section>
    <div class="footer"><span>인터넷 연결이 필요합니다. 자사 기사 전문 캡처 때문에 기사 수에 따라 생성 시간이 조금 더 걸릴 수 있습니다.</span><button class="button danger" id="shutdownBtn">생성기 종료</button></div>
  </main>
  <script>
    const TOKEN="__TOKEN__";const $=id=>document.getElementById(id);let currentJob=null;const fields=["client","reportDate","brand","competitors","output"];
    function restore(){for(const id of fields){const v=localStorage.getItem("dm_vb_"+id);if(v!==null)$(id).value=v}}
    function persist(){for(const id of fields)localStorage.setItem("dm_vb_"+id,$(id).value)}
    function linkCount(){const m=$("links").value.match(/https?:\/\/[^\s<>"']+/g)||[];$("count").textContent=new Set(m).size+"개"}
    function setStatus(text,kind=""){$("status").textContent=text;$("status").className="status show "+kind}
    function friendlyMessage(e){if(e instanceof TypeError){return "서버에 연결할 수 없습니다. 이 창을 닫고 \"데일리 모니터링 생성기 실행.cmd\"를 다시 실행해 주세요."}return e.message}
    async function generate(){const links=$("links").value.trim();if(!links){setStatus("기사 링크를 한 개 이상 넣어 주세요.","error");return}persist();$("generateBtn").disabled=true;$("openBtn").style.display="none";$("bar").classList.add("show");setStatus("생성 작업을 시작하는 중...");const body={links,client:$("client").value,report_date:$("reportDate").value,brand:$("brand").value,competitors:$("competitors").value,banner:true,output:$("output").value};try{const res=await fetch("/api/generate?token="+encodeURIComponent(TOKEN),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const data=await res.json();if(!res.ok)throw new Error(data.error||"생성 작업을 시작하지 못했습니다.");currentJob=data.job;poll()}catch(e){finishError(friendlyMessage(e))}}
    async function poll(){try{const res=await fetch("/api/status?token="+encodeURIComponent(TOKEN)+"&job="+encodeURIComponent(currentJob));const data=await res.json();if(!res.ok)throw new Error(data.error||"상태 확인 실패");setStatus(data.message||"처리 중...");if(data.done){if(data.error){finishError(data.error)}else{finishSuccess(data)}return}setTimeout(poll,800)}catch(e){finishError(friendlyMessage(e))}}
    function finishError(message){$("bar").classList.remove("show");$("generateBtn").disabled=false;setStatus("생성 실패\n"+message,"error")}
    function finishSuccess(data){$("bar").classList.remove("show");$("generateBtn").disabled=false;$("openBtn").style.display="inline-block";setStatus("완료\n"+data.output+"\n전체 기사 "+data.article_count+"개 · 자사 전문 캡처 "+(data.own_capture_pages||0)+"페이지 · 캡처 확인 필요 "+(data.capture_failed_count||0)+"개","success")}
    async function openOutput(){if(!currentJob)return;await fetch("/api/open?token="+encodeURIComponent(TOKEN)+"&job="+encodeURIComponent(currentJob))}
    async function shutdown(){await fetch("/api/shutdown?token="+encodeURIComponent(TOKEN));document.body.innerHTML="<main class='wrap'><div class='card'><h2>생성기를 종료했습니다.</h2><p>이 창을 닫아도 됩니다.</p></div></main>"}
    async function checkHealth(){try{const res=await fetch("/api/version",{cache:"no-store"});$("connWarning").style.display=res.ok?"none":"block"}catch(e){$("connWarning").style.display="block"}}
    restore();linkCount();$("links").addEventListener("input",linkCount);$("generateBtn").addEventListener("click",generate);$("openBtn").addEventListener("click",openOutput);$("shutdownBtn").addEventListener("click",shutdown);
    checkHealth();setInterval(checkHealth,15000);
  </script>
</body></html>"""


def _json_response(handler: BaseHTTPRequestHandler, payload: dict, status: int = 200):
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(data)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    handler.wfile.write(data)


def _authorized(query: dict[str, list[str]]) -> bool:
    return query.get("token", [""])[0] == AUTH_TOKEN


def _keywords(value: str) -> list[str]:
    return [piece.strip() for piece in value.replace("\n", ",").split(",") if piece.strip()]


def _worker(job_id: str, request: dict):
    def progress(message: str):
        with JOBS_LOCK:
            if job_id in JOBS:
                JOBS[job_id]["message"] = message
    try:
        output, articles, verification = generate_report(
            raw_links=str(request.get("links", "")),
            client_code=str(request.get("client", "VB")).strip() or "VB",
            brand_keywords=_keywords(str(request.get("brand", ""))),
            competitor_keywords=_keywords(str(request.get("competitors", ""))),
            report_date_input=str(request.get("report_date", "")).strip(),
            output_directory=Path(str(request.get("output", DEFAULT_OUTPUT))).expanduser(),
            reference_path=REFERENCE_PATH,
            preserve_reference_banner=bool(request.get("banner", True)),
            progress=progress,
        )
        with JOBS_LOCK:
            JOBS[job_id].update({"done":True,"error":"","message":"Word 보고서 생성 완료","output":str(output),"article_count":len(articles),"failed_count":sum(1 for article in articles if article.error),"own_capture_pages":verification.get("own_capture_pages",0),"capture_failed_count":verification.get("capture_failures",0),"verification":verification})
    except Exception as exc:
        with JOBS_LOCK:
            JOBS[job_id].update({"done":True,"error":f"{type(exc).__name__}: {exc}","message":"생성 중 오류가 발생했습니다."})


class SingleInstanceHTTPServer(ThreadingHTTPServer):
    allow_reuse_address = False
    allow_reuse_port = False

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


class Handler(BaseHTTPRequestHandler):
    server_version = "DailyMonitoring/1.0"
    def log_message(self, _format, *args):
        return
    def do_GET(self):
        parsed = urllib.parse.urlsplit(self.path);query = urllib.parse.parse_qs(parsed.query)
        if parsed.path == "/":
            escaped_output = str(DEFAULT_OUTPUT).replace("&", "&amp;").replace('"', "&quot;")
            page = HTML_TEMPLATE.replace("__TOKEN__", AUTH_TOKEN).replace("__TODAY__", date.today().isoformat()).replace("__DEFAULT_OUTPUT__", escaped_output).encode("utf-8")
            self.send_response(200);self.send_header("Content-Type", "text/html; charset=utf-8");self.send_header("Content-Length", str(len(page)));self.send_header("Cache-Control", "no-store");self.end_headers();self.wfile.write(page);return
        if parsed.path == "/api/version":
            _json_response(self,{"version":APP_VERSION});return
        if parsed.path == "/api/shutdown-stale":
            _json_response(self,{"ok":True});threading.Thread(target=SERVER.shutdown,daemon=True).start();return
        if not _authorized(query):
            _json_response(self,{"error":"권한 토큰이 올바르지 않습니다."},403);return
        if parsed.path == "/api/status":
            job_id=query.get("job",[""])[0]
            with JOBS_LOCK: job=dict(JOBS.get(job_id,{}))
            _json_response(self,job if job else {"error":"작업을 찾을 수 없습니다."},200 if job else 404);return
        if parsed.path == "/api/open":
            job_id=query.get("job",[""])[0]
            with JOBS_LOCK: job=dict(JOBS.get(job_id,{}))
            output=Path(job.get("output","")) if job.get("output") else None
            if not output or not output.exists(): _json_response(self,{"error":"완성 파일을 찾을 수 없습니다."},404);return
            try: subprocess.Popen(["explorer.exe","/select,",str(output)],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);_json_response(self,{"ok":True})
            except Exception as exc: _json_response(self,{"error":str(exc)},500)
            return
        if parsed.path == "/api/shutdown":
            _json_response(self,{"ok":True});threading.Thread(target=SERVER.shutdown,daemon=True).start();return
        if parsed.path == "/api/health": _json_response(self,{"ok":True});return
        _json_response(self,{"error":"경로를 찾을 수 없습니다."},404)
    def do_POST(self):
        parsed=urllib.parse.urlsplit(self.path);query=urllib.parse.parse_qs(parsed.query)
        if not _authorized(query): _json_response(self,{"error":"권한 토큰이 올바르지 않습니다."},403);return
        if parsed.path != "/api/generate": _json_response(self,{"error":"경로를 찾을 수 없습니다."},404);return
        try:
            length=int(self.headers.get("Content-Length","0"))
            if length <= 0 or length > 2_000_000: raise ValueError("요청 크기가 올바르지 않습니다.")
            request=json.loads(self.rfile.read(length).decode("utf-8"))
            if not str(request.get("links","")).strip(): raise ValueError("기사 링크를 입력해 주세요.")
            if not REFERENCE_PATH.exists(): raise FileNotFoundError(f"기준 Word 파일이 없습니다: {REFERENCE_PATH}")
            job_id=uuid4().hex
            with JOBS_LOCK: JOBS[job_id]={"done":False,"error":"","message":"기사 링크를 확인하는 중..."}
            threading.Thread(target=_worker,args=(job_id,request),daemon=True).start();_json_response(self,{"job":job_id},202)
        except Exception as exc: _json_response(self,{"error":f"{type(exc).__name__}: {exc}"},400)


def _open_app(url: str):
    try:
        subprocess.Popen(
            ["explorer.exe", url],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return
    except Exception:
        pass
    webbrowser.open(url)


def _existing_app_is_running(url: str) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=2) as response:
            body = response.read(120_000).decode("utf-8", "replace")
        return "바이탈뷰티 데일리 모니터링 Word 생성기" in body
    except Exception:
        return False


def _fetch_json(url: str, timeout: float = 2.0) -> dict | None:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            return json.loads(response.read(120_000).decode("utf-8", "replace"))
    except Exception:
        return None


def main():
    global SERVER
    DEFAULT_OUTPUT.mkdir(parents=True,exist_ok=True)
    base_url=f"http://127.0.0.1:{APP_PORT}/"
    try:
        SERVER=SingleInstanceHTTPServer(("127.0.0.1",APP_PORT),Handler)
    except OSError:
        if not _existing_app_is_running(base_url):
            raise
        version_info = _fetch_json(base_url + "api/version")
        is_stale = version_info is not None and version_info.get("version") != APP_VERSION
        if is_stale:
            # An older copy of this app (from a previous folder/zip) is still
            # running and would otherwise keep serving its old in-memory code
            # forever, silently ignoring this update - restart it.
            _fetch_json(base_url + "api/shutdown-stale")
            for _ in range(20):
                time.sleep(0.25)
                try:
                    SERVER = SingleInstanceHTTPServer(("127.0.0.1", APP_PORT), Handler)
                    break
                except OSError:
                    continue
            else:
                _open_app(base_url)
                return
        else:
            _open_app(base_url)
            return
    url=f"{base_url}?token={urllib.parse.quote(AUTH_TOKEN)}"
    threading.Timer(0.5,lambda:_open_app(url)).start()
    try: SERVER.serve_forever(poll_interval=0.4)
    finally: SERVER.server_close()


def _show_startup_error(exc: Exception):
    # This runs under pythonw.exe, which has no console - an unhandled exception
    # here would otherwise fail completely silently (double-click does nothing,
    # no window, no clue why), which is exactly the kind of dead end that makes
    # a "Failed to fetch" report from another PC hard to diagnose remotely.
    message = (
        "생성기를 시작하지 못했습니다.\n\n"
        f"{type(exc).__name__}: {exc}\n\n"
        "다른 보안 소프트웨어가 로컬 프로그램의 네트워크 사용을 막고 있을 수 있습니다.\n"
        "회사 PC라면 IT 담당자에게 python.exe/pythonw.exe의 127.0.0.1 통신 허용을 요청해 주세요."
    )
    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(0, message, "바이탈뷰티 데일리 모니터링 Word 생성기", 0x10)
    except Exception:
        pass


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        _show_startup_error(exc)
