"""오아시스마켓 데일리 모니터링 Word 생성기 — 실행 화면.

링크를 붙여 넣고 [보고서 만들기]를 누르면 Word 파일이 나온다.
"""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import traceback
from datetime import date, datetime
from pathlib import Path

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

import oasis_report as orep  # noqa: E402

DEFAULT_OUTPUT = Path.home() / "Documents" / "OASIS Daily Monitoring"

PLACEHOLDER = """여기에 기사 링크를 한 줄에 하나씩 붙여 넣으세요.

분류를 직접 지정하려면 링크 위에 이렇게 적으면 됩니다.

[보도자료]
https://...
https://...

[오아시스]
https://...

경쟁사
https://...

쓸 수 있는 이름
  자사 · 경쟁사 · 업계
  보도자료 · 오아시스 · 티몬 · 오아시스/티몬
  단순언급_오아시스 · 단순언급_티몬

아무것도 안 적으면 기사 내용을 보고 알아서 나눕니다.
나눈 결과는 초안이니 Word에서 확인하고 고치세요."""


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("오아시스마켓 데일리 모니터링 Word 생성기")
        self.geometry("880x680")
        self.minsize(760, 560)

        self.output_dir = tk.StringVar(value=str(DEFAULT_OUTPUT))
        self.report_date = tk.StringVar(value=date.today().strftime("%Y-%m-%d"))
        self.status = tk.StringVar(value="링크를 붙여 넣고 아래 버튼을 누르세요.")
        self.busy = False
        self.last_output: Path | None = None

        self._build()

    def _build(self):
        pad = {"padx": 14, "pady": 6}

        header = ttk.Frame(self)
        header.pack(fill="x", **pad)
        ttk.Label(header, text="Daily Monitoring Report · OASIS",
                  font=("맑은 고딕", 15, "bold")).pack(side="left")

        row = ttk.Frame(self)
        row.pack(fill="x", **pad)
        ttk.Label(row, text="보고서 날짜").pack(side="left")
        ttk.Entry(row, textvariable=self.report_date, width=14).pack(side="left", padx=(6, 18))
        ttk.Label(row, text="저장 위치").pack(side="left")
        ttk.Entry(row, textvariable=self.output_dir).pack(side="left", fill="x",
                                                          expand=True, padx=6)
        ttk.Button(row, text="바꾸기", command=self.pick_folder).pack(side="left")

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True, **pad)
        ttk.Label(body, text="기사 링크").pack(anchor="w")
        self.text = tk.Text(body, wrap="word", height=16, font=("맑은 고딕", 10),
                            undo=True)
        self.text.pack(fill="both", expand=True, pady=(4, 0))
        self.text.insert("1.0", PLACEHOLDER)
        self.text.configure(fg="#888888")
        self.text.bind("<FocusIn>", self._clear_placeholder)

        log_frame = ttk.Frame(self)
        log_frame.pack(fill="both", expand=True, **pad)
        ttk.Label(log_frame, text="진행 상황").pack(anchor="w")
        self.log = tk.Text(log_frame, wrap="word", height=9, font=("맑은 고딕", 9),
                           state="disabled", background="#f7f7f7")
        self.log.pack(fill="both", expand=True, pady=(4, 0))

        footer = ttk.Frame(self)
        footer.pack(fill="x", **pad)
        ttk.Label(footer, textvariable=self.status).pack(side="left")
        self.open_button = ttk.Button(footer, text="폴더 열기", command=self.open_folder,
                                      state="disabled")
        self.open_button.pack(side="right", padx=(8, 0))
        self.run_button = ttk.Button(footer, text="보고서 만들기", command=self.run)
        self.run_button.pack(side="right")

    def _clear_placeholder(self, _event=None):
        if self.text.get("1.0", "end").strip() == PLACEHOLDER.strip():
            self.text.delete("1.0", "end")
            self.text.configure(fg="#000000")

    def pick_folder(self):
        chosen = filedialog.askdirectory(initialdir=self.output_dir.get() or str(Path.home()))
        if chosen:
            self.output_dir.set(chosen)

    def write_log(self, message: str):
        def append():
            self.log.configure(state="normal")
            self.log.insert("end", message + "\n")
            self.log.see("end")
            self.log.configure(state="disabled")
        self.after(0, append)

    def open_folder(self):
        if not self.last_output:
            return
        try:
            os.startfile(self.last_output.parent)  # noqa: S606
        except Exception:
            subprocess.Popen(["explorer", str(self.last_output.parent)])

    def run(self):
        if self.busy:
            return
        raw = self.text.get("1.0", "end").strip()
        if not raw or raw == PLACEHOLDER.strip():
            messagebox.showinfo("링크가 없습니다", "기사 링크를 먼저 붙여 넣어 주세요.")
            return
        try:
            report_day = datetime.strptime(self.report_date.get().strip(), "%Y-%m-%d").date()
        except ValueError:
            messagebox.showerror("날짜 형식", "보고서 날짜는 2026-08-28 형태로 적어 주세요.")
            return

        self.busy = True
        self.run_button.configure(state="disabled")
        self.open_button.configure(state="disabled")
        self.log.configure(state="normal")
        self.log.delete("1.0", "end")
        self.log.configure(state="disabled")
        self.status.set("기사를 읽는 중입니다...")

        threading.Thread(target=self._work, args=(raw, report_day), daemon=True).start()

    def _work(self, raw: str, report_day: date):
        try:
            def progress(index, total, url):
                self.write_log(f"[{index}/{total}] {url}")
                self.after(0, lambda: self.status.set(f"기사를 읽는 중입니다... {index}/{total}"))

            path, items = orep.generate(raw, report_day, Path(self.output_dir.get()),
                                        progress=progress)
            self.last_output = path

            failed = [i for i in items if i.error]
            self.write_log("")
            self.write_log(f"만들었습니다: {path.name}")
            self.write_log("")
            for key, label in orep.MAJOR_SECTIONS:
                group = [i for i in items if i.major == key]
                if group:
                    self.write_log(f"{label} {len(group)}건")
                    for item in group:
                        tag = f"{item.subgroup} " if item.subgroup else ""
                        self.write_log(f"   {tag}{item.title[:48]} / {item.publication}")
            if failed:
                self.write_log("")
                self.write_log(f"읽지 못한 링크 {len(failed)}건 — Word에서 직접 채워 주세요.")
                for item in failed:
                    self.write_log(f"   {item.url}  ({item.error})")
            self.write_log("")
            self.write_log("분류는 초안입니다. Word에서 확인하고 고쳐 주세요.")

            self.after(0, lambda: self.status.set(f"완료 · {path.name}"))
            self.after(0, lambda: self.open_button.configure(state="normal"))
        except Exception as exc:
            detail = traceback.format_exc()
            self.write_log(detail)
            self.after(0, lambda: self.status.set("실패했습니다."))
            self.after(0, lambda: messagebox.showerror("만들지 못했습니다", str(exc)))
        finally:
            self.busy = False
            self.after(0, lambda: self.run_button.configure(state="normal"))


if __name__ == "__main__":
    App().mainloop()
