from __future__ import annotations

import copy
import gzip
import html as html_module
import io
import json
import re
import shutil
import ssl
import subprocess
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
import zlib
from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Callable, Iterable

from lxml import etree, html
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_COLOR_INDEX
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


DARK_GRAY = "404040"
SECTION_GRAY = "D9D9D9"
KEYWORD_GRAY = "F2F2F2"
SUBGROUP_GRAY = "E7E6E6"
LINK_TEAL = "2A7886"
WHITE = "FFFFFF"
BLACK = "000000"
ALERT_RED = "C00000"

CATEGORY_LABELS = {
    "own": "Company News",
    "competitor": "Competitor News",
    "industry": "Industry News",
}

INGREDIENT_KEYWORDS = [
    "카테킨", "녹차카테킨", "가르시니아", "콜라겐", "글루타치온", "비오틴",
    "NMN", "레티놀", "먹는레티놀", "유산균",
]

INDUSTRY_KEYWORDS = [
    "아모레퍼시픽", "건강기능식품", "건강식품", "건기식", "이너뷰티", "뷰티푸드",
    "뷰티식품", "다이어트보조제", "슬리밍제품", "다이어트약", "다이어트식품",
    "위고비", "삭센다", "마운자로", "알파CD", "수면영양제", "에너지드링크",
    "멀티비타민", "프리미엄비타민", "프리미엄영양제", "뷰티비타민", "맞춤영양제",
]

CATEGORY_MARKERS = {
    "자사": "own",
    "자사 관련 뉴스": "own",
    "경쟁사": "competitor",
    "경쟁사 관련 뉴스": "competitor",
    "성분": "ingredient",
    "성분 관련 뉴스": "ingredient",
    "업계": "industry",
    "업계 관련 뉴스": "industry",
}

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)

BOILERPLATE_PATTERNS = re.compile(
    r"(무단\s*전재|재배포\s*금지|저작권자|copyright|ⓒ|기사제보|구독|로그인|"
    r"관련기사|관련\s*뉴스|많이\s*본\s*뉴스|인기\s*기사|추천\s*기사|실시간\s*급상승|"
    r"댓글|기자\s*=|기자\s*$|페이스북|카카오톡|네이버\s*채널|텔레그램|트위터|"
    r"[\w.+-]+@[\w-]+\.[\w.-]+|공유하기|url\s*복사|기사\s*스크랩)",
    re.IGNORECASE,
)

END_MARKER_PATTERNS = re.compile(
    r"(무단\s*전재|재배포\s*금지|저작권자|copyright|ⓒ\s*\d{4}|기사제보|"
    r"관련기사|관련\s*뉴스|많이\s*본\s*뉴스|인기\s*기사|추천\s*기사|실시간\s*급상승)",
    re.IGNORECASE,
)

CAPTION_PREFIX_PATTERN = re.compile(r"^(▲|△|\[사진|\(사진|사진\s*=|사진\s*제공|photo\s*[:=])", re.IGNORECASE)
RELATED_WIDGET_PATTERN = re.compile(r"(관련\s*기사|관련\s*뉴스|많이\s*본|인기\s*기사|추천\s*기사|프로필|기자\s*사진)", re.IGNORECASE)
DEAD_LINK_PATTERN = re.compile(
    r"(기사가\s*삭제|삭제되었거나|보유기간이\s*종료|기사를\s*찾을\s*수\s*없|"
    r"페이지를\s*찾을\s*수\s*없|존재하지\s*않는\s*페이지|page\s*not\s*found|404\s*error)",
    re.IGNORECASE,
)
MAX_INLINE_IMAGES = 5

@dataclass
class InputLink:
    url: str
    category_override: str | None = None


@dataclass
class Article:
    url: str
    final_url: str
    category: str
    title: str
    publication: str
    published_date: str
    description: str
    body: str
    image_path: Path | None
    content_blocks: list[dict] = field(default_factory=list)
    error: str = ""
    capture_paths: list[Path] = field(default_factory=list)
    capture_error: str = ""

    @property
    def summary(self) -> str:
        return summarize_article(self.description, self.body)


def _clean_space(value: str | None) -> str:
    if not value:
        return ""
    value = html_module.unescape(value)
    value = value.replace("\u200b", " ").replace("\xa0", " ")
    return re.sub(r"\s+", " ", value).strip()


def _sanitize_url(url: str) -> str:
    url = url.strip().strip("<>[](){}\"'")
    while url and url[-1] in ".,;":
        url = url[:-1]
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qs(parsed.query)
    # Many press-release/tracking hubs (naver search, buzzms, etc.) wrap the real
    # article URL in a query param and redirect to it via client-side JS, which our
    # plain HTTP fetch never runs. The real target is already sitting in the query
    # string, so unwrap it directly instead of fetching the redirector stub page.
    for key in ("u", "url", "link", "target", "redirect", "redirect_url", "goto"):
        candidate = query.get(key, [""])[0]
        if candidate.startswith(("http://", "https://")):
            candidate_host = urllib.parse.urlsplit(candidate).hostname
            if candidate_host and candidate_host != parsed.hostname:
                return candidate
    return url


def parse_link_input(raw: str) -> list[InputLink]:
    current_category: str | None = None
    found: list[InputLink] = []
    seen: set[str] = set()
    for original_line in raw.splitlines():
        line = original_line.strip()
        if not line:
            continue
        marker = re.sub(r"[\[\]#:]", "", line).strip()
        if marker in CATEGORY_MARKERS:
            current_category = CATEGORY_MARKERS[marker]
            continue
        inline_override = current_category
        prefix = re.match(r"^(자사|경쟁사|성분|업계)\s*[|,:\-]\s*(.+)$", line)
        if prefix:
            inline_override = CATEGORY_MARKERS[prefix.group(1)]
            line = prefix.group(2)
        for match in re.findall(r"https?://[^\s<>\"']+", line):
            url = _sanitize_url(match)
            if url and url not in seen:
                seen.add(url)
                found.append(InputLink(url=url, category_override=inline_override))
    return found


def _decode_body(raw: bytes, headers) -> str:
    content_encoding = (headers.get("Content-Encoding") or "").lower()
    if "gzip" in content_encoding:
        raw = gzip.decompress(raw)
    elif "deflate" in content_encoding:
        raw = zlib.decompress(raw)
    content_type = headers.get("Content-Type") or ""
    charset_match = re.search(r"charset\s*=\s*[\"']?([\w.\-]+)", content_type, re.I)
    probe = raw[:5000]
    if not charset_match:
        charset_match = re.search(br"charset\s*=\s*[\"']?([\w.\-]+)", probe, re.I)
    candidates: list[str] = []
    if charset_match:
        value = charset_match.group(1)
        candidates.append(value.decode("ascii", "ignore") if isinstance(value, bytes) else value)
    candidates.extend(["utf-8", "cp949", "euc-kr"])
    def _has_hangul(value: str) -> bool:
        return any("가" <= ch <= "힣" for ch in value)

    decoded = None
    for encoding in candidates:
        try:
            decoded = raw.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
        # Some Korean sites declare a Latin charset but serve EUC-KR/CP949.
        # A Latin codec never fails, so the result is silently mojibake.
        # If nothing decoded as Hangul, give the Korean codecs a chance.
        if not _has_hangul(decoded):
            for fallback in ("cp949", "euc-kr", "utf-8"):
                if fallback == encoding:
                    continue
                try:
                    candidate = raw.decode(fallback)
                except (UnicodeDecodeError, LookupError):
                    continue
                if _has_hangul(candidate):
                    return candidate
        return decoded

    # Every codec raised: the page mixes in a few invalid bytes.
    # Decode leniently and keep whichever result recovers the most Hangul,
    # so a handful of bad bytes cannot throw away the whole article.
    best = ""
    best_score = -1
    for encoding in candidates:
        try:
            candidate = raw.decode(encoding, "replace")
        except LookupError:
            continue
        score = sum(1 for ch in candidate if "가" <= ch <= "힣")
        if score > best_score:
            best, best_score = candidate, score
    return best or raw.decode("utf-8", "replace")


def _build_ssl_context() -> ssl.SSLContext:
    try:
        import certifi

        return ssl.create_default_context(cafile=certifi.where())
    except Exception:
        return ssl.create_default_context()


SSL_CONTEXT = _build_ssl_context()


def _fetch_bytes(url: str, timeout: int = 20, max_bytes: int = 12_000_000):
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/*,*/*;q=0.8",
            "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.7,en;q=0.6",
            "Accept-Encoding": "gzip, deflate",
            "Cache-Control": "no-cache",
        },
    )
    with urllib.request.urlopen(request, timeout=timeout, context=SSL_CONTEXT) as response:
        data = response.read(max_bytes + 1)
        if len(data) > max_bytes:
            raise ValueError("응답 크기가 너무 큽니다.")
        return data, response.headers, response.geturl()


def _meta_map(root) -> dict[str, str]:
    values: dict[str, str] = {}
    for node in root.xpath("//meta[@content]"):
        key = (node.get("property") or node.get("name") or "").strip().lower()
        content = _clean_space(node.get("content"))
        if key and content and key not in values:
            values[key] = content
    return values


def _json_ld_items(root) -> list[dict]:
    items: list[dict] = []
    for node in root.xpath("//script[contains(translate(@type,'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'ld+json')]"):
        text_value = node.text or ""
        if not text_value.strip():
            continue
        try:
            parsed = json.loads(text_value)
        except Exception:
            continue
        queue = parsed if isinstance(parsed, list) else [parsed]
        while queue:
            value = queue.pop(0)
            if not isinstance(value, dict):
                continue
            graph = value.get("@graph")
            if isinstance(graph, list):
                queue.extend(graph)
            items.append(value)
    return items


def _pick_json_ld(items: Iterable[dict]) -> dict:
    preferred = {"newsarticle", "article", "reportagenewsarticle", "blogposting"}
    for item in items:
        item_type = item.get("@type", "")
        types = item_type if isinstance(item_type, list) else [item_type]
        if any(str(value).lower() in preferred for value in types):
            return item
    return next(iter(items), {})


def _node_text(node) -> str:
    return _clean_space(" ".join(node.itertext()))


def _image_src(node) -> str:
    for attr in ("src", "data-src", "data-original", "data-lazy-src", "data-original-src"):
        value = node.get(attr)
        if value and not value.startswith("data:"):
            return value
    srcset = node.get("srcset") or node.get("data-srcset")
    if srcset:
        candidate = srcset.split(",")[0].strip().split(" ")[0].strip()
        if candidate and not candidate.startswith("data:"):
            return candidate
    return ""


def _find_image_caption(img_node) -> tuple[str, object | None]:
    parent = img_node.getparent()
    if parent is not None:
        figcaptions = parent.xpath(".//figcaption")
        if figcaptions:
            text_value = _node_text(figcaptions[0])
            if text_value:
                return text_value[:160], figcaptions[0]
        sibling = img_node.getnext()
        hops = 0
        while sibling is not None and hops < 3:
            if not isinstance(sibling.tag, str):
                sibling = sibling.getnext()
                continue
            text_value = _node_text(sibling)
            klass = (sibling.get("class") or "").lower()
            if text_value and (CAPTION_PREFIX_PATTERN.match(text_value) or "caption" in klass or "desc" in klass):
                return text_value[:160], sibling
            if text_value:
                break
            sibling = sibling.getnext()
            hops += 1
    alt = _clean_space(img_node.get("alt") or "")
    if alt and len(alt) >= 6 and alt.lower() not in {"image", "img", "photo", "이미지", "사진"}:
        return alt[:160], None
    return "", None


BLOCK_LEVEL_TAGS = {"p", "div", "li", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "tr", "br"}


def _extract_content_blocks(node) -> list[dict]:
    working = copy.deepcopy(node)
    for element in working.iter():
        tag = element.tag.lower() if isinstance(element.tag, str) else ""
        if tag in BLOCK_LEVEL_TAGS:
            element.tail = "\n\n" + (element.tail or "")

    blocks: list[dict] = []
    seen_images: set[str] = set()
    consumed_ids: set[int] = set()
    seen_captions: set[str] = set()
    image_count = 0
    buffer_parts: list[str] = []
    stopped = False

    def fingerprint(text_value: str) -> str:
        return re.sub(r"\W", "", text_value)[:80]

    def is_consumed(element) -> bool:
        while element is not None:
            if id(element) in consumed_ids:
                return True
            element = element.getparent()
        return False

    def flush_buffer():
        nonlocal stopped
        raw = "".join(buffer_parts)
        buffer_parts.clear()
        for piece in re.split(r"(?:\r?\n){2,}", raw):
            if stopped:
                return
            text_value = _clean_space(piece)
            if not text_value:
                continue
            if END_MARKER_PATTERNS.search(text_value):
                stopped = True
                return
            if len(text_value) < 20 or BOILERPLATE_PATTERNS.search(text_value):
                continue
            if fingerprint(text_value) in seen_captions:
                continue
            blocks.append({"type": "text", "value": text_value})

    for item in working.xpath(".//text() | .//img"):
        if stopped:
            break
        if isinstance(item, str):
            if not is_consumed(item.getparent()):
                buffer_parts.append(item)
            continue
        if image_count >= MAX_INLINE_IMAGES:
            continue
        src = _image_src(item)
        if not src or src in seen_images:
            continue
        seen_images.add(src)
        caption, caption_element = _find_image_caption(item)
        if caption and RELATED_WIDGET_PATTERN.search(caption):
            if caption_element is not None:
                consumed_ids.add(id(caption_element))
            continue
        flush_buffer()
        if stopped:
            break
        image_count += 1
        if caption_element is not None:
            consumed_ids.add(id(caption_element))
        if caption:
            seen_captions.add(fingerprint(caption))
        blocks.append({"type": "image", "src": src, "caption": caption})
    flush_buffer()
    return blocks


def _dedupe_text_blocks(blocks: list[dict]) -> list[dict]:
    seen: set[str] = set()
    cleaned: list[dict] = []
    for block in blocks:
        if block["type"] == "text":
            fingerprint = re.sub(r"\W", "", block["value"])[:80]
            if fingerprint in seen:
                continue
            seen.add(fingerprint)
        cleaned.append(block)
    return cleaned


ARTICLE_NODE_XPATHS = [
    "//*[@itemprop='articleBody']",
    "//*[@id='dic_area']",
    "//*[@id='articleBody']",
    "//*[@id='article-body']",
    "//*[contains(concat(' ', normalize-space(@class), ' '), ' article-body ')]",
    "//*[contains(concat(' ', normalize-space(@class), ' '), ' article_body ')]",
    "//*[contains(concat(' ', normalize-space(@class), ' '), ' newsct_article ')]",
    "//*[contains(concat(' ', normalize-space(@class), ' '), ' article-view-content-div ')]",
    "//article",
]


def _select_article_node(root):
    for removable in root.xpath("//script|//style|//noscript|//nav|//aside|//footer|//form"):
        parent = removable.getparent()
        if parent is not None:
            parent.remove(removable)

    candidates = []
    for xpath in ARTICLE_NODE_XPATHS:
        for node in root.xpath(xpath):
            text_value = _node_text(node)
            if len(text_value) >= 150:
                link_text = _clean_space(" ".join(a.text_content() for a in node.xpath(".//a")))
                link_density = len(link_text) / max(len(text_value), 1)
                score = len(text_value) * max(0.1, 1.0 - link_density)
                candidates.append((score, node))
    if candidates:
        return max(candidates, key=lambda item: item[0])[1]
    fallback_node = root.xpath("//body")
    return fallback_node[0] if fallback_node else root


def _extract_body_and_blocks(root, json_ld: dict, description: str) -> tuple[str, list[dict]]:
    article_body = json_ld.get("articleBody") if isinstance(json_ld, dict) else ""
    if isinstance(article_body, str) and len(_clean_space(article_body)) >= 120:
        text_value = _clean_space(article_body)[:18_000]
        blocks = [{"type": "text", "value": piece} for piece in text_value.split("\n\n") if piece.strip()]
        return text_value, blocks

    working_node = _select_article_node(root)
    blocks = _extract_content_blocks(working_node)
    blocks = _dedupe_text_blocks(blocks)
    body = "\n\n".join(block["value"] for block in blocks if block["type"] == "text")
    if not body:
        body = description
        blocks = [{"type": "text", "value": description}] if description else []
    return body[:45_000], blocks


def _parse_date(value: str) -> str:
    value = _clean_space(value)
    if not value:
        return ""
    match = re.search(r"(20\d{2})[-./년\s]+(\d{1,2})[-./월\s]+(\d{1,2})", value)
    if match:
        return f"{int(match.group(1)) % 100:02d}.{int(match.group(2)):02d}.{int(match.group(3)):02d}"
    return value[:20]


def _hostname_publication(url: str) -> str:
    host = (urllib.parse.urlsplit(url).hostname or "").lower().removeprefix("www.")
    known = {
        "news1.kr": "뉴스1",
        "yna.co.kr": "연합뉴스",
        "newsis.com": "뉴시스",
        "mk.co.kr": "매일경제",
        "etoday.co.kr": "이투데이",
        "edaily.co.kr": "이데일리",
        "nutritioninsight.com": "nutrition insight",
    }
    for domain, name in known.items():
        if host == domain or host.endswith("." + domain):
            return name
    return host or "매체 확인 필요"


AD_IMAGE_PATTERN = re.compile(
    r"(banner|adimg|ad_img|/ads?/|advertise|widget|promo|logo|sprite|icon|button|btn_)",
    re.IGNORECASE,
)


def _download_image(image_url: str, base_url: str, temp_dir: Path) -> Path | None:
    if not image_url:
        return None
    absolute = urllib.parse.urljoin(base_url, image_url)
    if AD_IMAGE_PATTERN.search(absolute):
        return None
    try:
        raw, headers, _ = _fetch_bytes(absolute, timeout=15, max_bytes=10_000_000)
        content_type = (headers.get("Content-Type") or "").lower()
        if "image" not in content_type and not absolute.lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
            return None
        with Image.open(io.BytesIO(raw)) as image:
            if image.width < 220 or image.height < 140:
                return None
            aspect = image.width / max(image.height, 1)
            if aspect > 3.2 or aspect < 0.3:
                return None
            image.load()
            if image.mode not in ("RGB", "RGBA"):
                image = image.convert("RGB")
            if image.mode == "RGBA":
                background = Image.new("RGB", image.size, "white")
                background.paste(image, mask=image.getchannel("A"))
                image = background
            path = temp_dir / f"lead-{len(list(temp_dir.glob('lead-*'))) + 1:03d}.jpg"
            image.convert("RGB").save(path, "JPEG", quality=90, optimize=True)
            return path
    except Exception:
        return None


def classify_article(text: str, brand_keywords: list[str], competitor_keywords: list[str]) -> str:
    lowered = text.casefold()
    if any(keyword.casefold() in lowered for keyword in brand_keywords if keyword.strip()):
        return "own"
    if any(keyword.casefold() in lowered for keyword in competitor_keywords if keyword.strip()):
        return "competitor"
    if any(keyword.casefold() in lowered for keyword in INGREDIENT_KEYWORDS):
        return "ingredient"
    return "industry"


def _keyword_pool_for_category(category: str, brand_keywords: list[str], competitor_keywords: list[str]) -> list[str]:
    if category == "own":
        return brand_keywords
    if category == "competitor":
        return competitor_keywords
    if category == "ingredient":
        return INGREDIENT_KEYWORDS
    return INDUSTRY_KEYWORDS


def matched_keywords(text: str, pool: list[str]) -> list[str]:
    lowered = text.casefold()
    seen: set[str] = set()
    matched: list[str] = []
    for keyword in pool:
        keyword = keyword.strip()
        if not keyword:
            continue
        folded = keyword.casefold()
        if folded in lowered and folded not in seen:
            seen.add(folded)
            matched.append(keyword)
    return matched


def fetch_article(
    item: InputLink,
    brand_keywords: list[str],
    competitor_keywords: list[str],
    temp_dir: Path,
) -> Article:
    try:
        raw, headers, final_url = _fetch_bytes(item.url)
        markup = _decode_body(raw, headers)
        parser = html.HTMLParser(encoding="utf-8", recover=True)
        root = html.fromstring(markup.encode("utf-8", "ignore"), parser=parser, base_url=final_url)
        metas = _meta_map(root)
        json_ld = _pick_json_ld(_json_ld_items(root))

        publication = _clean_space(metas.get("og:site_name"))
        publisher = json_ld.get("publisher") if isinstance(json_ld, dict) else None
        if not publication and isinstance(publisher, dict):
            publication = _clean_space(publisher.get("name"))
        if publication.startswith(("http://", "https://")):
            publication = _hostname_publication(publication)
        publication = publication or _hostname_publication(final_url)

        h1_text = _clean_space(root.xpath("string(//h1[1])")) if root.xpath("//h1") else ""
        og_title = _clean_space(metas.get("og:title") or "")
        # Some sites put their own site/brand name in og:title instead of the real
        # headline - prefer a longer, more specific h1 when og:title looks generic.
        if og_title and h1_text and og_title != h1_text and (len(og_title) < 12 or og_title == publication):
            og_title = ""
        title = _clean_space(
            og_title
            or metas.get("twitter:title")
            or metas.get("title")
            or json_ld.get("headline")
            or h1_text
            or (root.xpath("string(//h2[1])") if root.xpath("//h2") else "")
            or root.xpath("string(//title)")
        )
        description = _clean_space(
            metas.get("og:description")
            or metas.get("description")
            or metas.get("twitter:description")
            or json_ld.get("description")
        )
        date_value = (
            metas.get("article:published_time")
            or metas.get("date")
            or json_ld.get("datePublished")
            or (root.xpath("string(//time[@datetime][1]/@datetime)") if root.xpath("//time[@datetime]") else "")
        )
        published_date = _parse_date(str(date_value)) or datetime.now().strftime("%y.%m.%d")
        if DEAD_LINK_PATTERN.search(f"{title} {_node_text(root)}"):
            raise ValueError("원문 기사가 삭제되었거나 만료되었습니다.")
        body, content_blocks = _extract_body_and_blocks(root, json_ld, description)
        image_value = metas.get("og:image") or metas.get("twitter:image") or ""
        if not image_value and isinstance(json_ld.get("image"), str):
            image_value = json_ld.get("image", "")
        elif not image_value and isinstance(json_ld.get("image"), dict):
            image_value = json_ld["image"].get("url", "")
        image_path = _download_image(str(image_value), final_url, temp_dir)
        combined = " ".join([title, description, body[:2500]])
        category = item.category_override or classify_article(combined, brand_keywords, competitor_keywords)
        return Article(
            url=item.url,
            final_url=final_url,
            category=category,
            title=title or f"{publication} 기사 (제목 확인 필요)",
            publication=publication,
            published_date=published_date,
            description=description,
            body=body,
            image_path=image_path,
            content_blocks=content_blocks,
        )
    except Exception as exc:
        publication = _hostname_publication(item.url)
        return Article(
            url=item.url,
            final_url=item.url,
            category=item.category_override or "industry",
            title=f"{publication} 기사 (수집 실패)",
            publication=publication,
            published_date=datetime.now().strftime("%y.%m.%d"),
            description="",
            body="",
            image_path=None,
            error=f"{type(exc).__name__}: {exc}",
        )


def _sentence_split(text: str) -> list[str]:
    text = _clean_space(text)
    if not text:
        return []
    pieces = re.split(r"(?<=[.!?。])\s+|(?<=다\.)\s+", text)
    return [piece.strip() for piece in pieces if len(piece.strip()) >= 20]


def summarize_article(description: str, body: str, max_chars: int = 430) -> str:
    description = _clean_space(description)
    if 60 <= len(description) <= max_chars:
        return description
    sentences = _sentence_split(body)
    chosen = []
    total = 0
    for sentence in sentences:
        if BOILERPLATE_PATTERNS.search(sentence):
            continue
        if chosen and total + len(sentence) > max_chars:
            break
        chosen.append(sentence)
        total += len(sentence) + 1
        if len(chosen) >= 3:
            break
    result = " ".join(chosen)
    if not result and description:
        result = description[:max_chars]
    if not result:
        return "기사 본문을 자동으로 불러오지 못했습니다. 원문 링크에서 내용을 확인해 주세요."
    return result[:max_chars].rstrip()


def _set_run_font(run, size: float | None = None, bold: bool | None = None, color: str | None = None):
    run.font.name = "맑은 고딕"
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    rfonts.set(qn("w:ascii"), "Malgun Gothic")
    rfonts.set(qn("w:hAnsi"), "Malgun Gothic")
    rfonts.set(qn("w:eastAsia"), "맑은 고딕")
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def _clear_document_body(doc: Document):
    body = doc._element.body
    for child in list(body):
        if child.tag != qn("w:sectPr"):
            body.remove(child)


def _set_cell_shading(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shading = tc_pr.find(qn("w:shd"))
    if shading is None:
        shading = OxmlElement("w:shd")
        tc_pr.append(shading)
    shading.set(qn("w:fill"), fill)


def _set_cell_margins(cell, top=100, start=120, bottom=100, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def _set_table_borders(table, color=BLACK, size="4", horizontal_only=False):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        element = borders.find(qn(f"w:{edge}"))
        if element is None:
            element = OxmlElement(f"w:{edge}")
            borders.append(element)
        hidden = horizontal_only and edge in {"left", "right", "insideV"}
        element.set(qn("w:val"), "nil" if hidden else "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), color)


def _set_table_geometry(table, widths_dxa: list[int]):
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.insert(0, tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths_dxa)))
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "-99")
    tbl_ind.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths_dxa:
        col = OxmlElement("w:gridCol")
        col.set(qn("w:w"), str(width))
        grid.append(col)
    for row in table.rows:
        column_index = 0
        handled = set()
        for cell in row.cells:
            identity = id(cell._tc)
            if identity in handled:
                continue
            handled.add(identity)
            tc_pr = cell._tc.get_or_add_tcPr()
            grid_span = tc_pr.find(qn("w:gridSpan"))
            span = int(grid_span.get(qn("w:val"))) if grid_span is not None else 1
            width = sum(widths_dxa[column_index : column_index + span])
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            column_index += span


def _add_hyperlink(paragraph, text: str, url: str, color=LINK_TEAL, bold=False, size=None, underline=False):
    part = paragraph.part
    rel_id = part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), rel_id)
    new_run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    r_fonts = OxmlElement("w:rFonts")
    r_fonts.set(qn("w:ascii"), "Malgun Gothic")
    r_fonts.set(qn("w:hAnsi"), "Malgun Gothic")
    r_fonts.set(qn("w:eastAsia"), "맑은 고딕")
    r_pr.append(r_fonts)
    color_node = OxmlElement("w:color")
    color_node.set(qn("w:val"), color)
    r_pr.append(color_node)
    if bold:
        r_pr.append(OxmlElement("w:b"))
    if size:
        size_node = OxmlElement("w:sz")
        size_node.set(qn("w:val"), str(int(size * 2)))
        r_pr.append(size_node)
    underline_node = OxmlElement("w:u")
    underline_node.set(qn("w:val"), "single" if underline else "none")
    r_pr.append(underline_node)
    new_run.append(r_pr)
    text_node = OxmlElement("w:t")
    text_node.text = text
    new_run.append(text_node)
    hyperlink.append(new_run)
    paragraph._p.append(hyperlink)


def _clear_list_formatting(paragraph):
    # Removing w:numPr outright still leaves any list numbering inherited from the
    # paragraph's style in effect (this reference template's "Normal" style carries
    # one), which is why a bullet could reappear depending on Word's zoom/render
    # pass. Writing numId=0 is the canonical OOXML way to force "no list" and
    # override that inheritance rather than just deleting the override.
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = p_pr.find(qn("w:numPr"))
    if num_pr is not None:
        p_pr.remove(num_pr)
    num_pr = OxmlElement("w:numPr")
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num_id = OxmlElement("w:numId")
    num_id.set(qn("w:val"), "0")
    num_pr.append(ilvl)
    num_pr.append(num_id)
    p_pr.append(num_pr)


def _new_paragraph(doc: Document, text="", size=10, bold=False, color=BLACK, after=4, before=0):
    paragraph = doc.add_paragraph()
    paragraph.style = doc.styles["Normal"]
    _clear_list_formatting(paragraph)
    paragraph.paragraph_format.space_before = Pt(before)
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.line_spacing = 1.1
    if text:
        run = paragraph.add_run(text)
        _set_run_font(run, size=size, bold=bold, color=color)
    return paragraph


def _set_paragraph_bottom_border(paragraph, color="808080", size="4", space="4"):
    p_pr = paragraph._p.get_or_add_pPr()
    p_bdr = p_pr.find(qn("w:pBdr"))
    if p_bdr is None:
        p_bdr = OxmlElement("w:pBdr")
        p_pr.append(p_bdr)
    bottom = p_bdr.find(qn("w:bottom"))
    if bottom is None:
        bottom = OxmlElement("w:bottom")
        p_bdr.append(bottom)
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), size)
    bottom.set(qn("w:space"), space)
    bottom.set(qn("w:color"), color)


def _set_row_cant_split(row):
    tr_pr = row._tr.get_or_add_trPr()
    if tr_pr.find(qn("w:cantSplit")) is None:
        tr_pr.append(OxmlElement("w:cantSplit"))


_WRAP_CJK_RE = re.compile(r"[가-힣ㄱ-ㆎ一-鿿＀-￯]")


def _tokenize_for_wrap(text: str) -> list[str]:
    tokens: list[str] = []
    buf = ""
    for ch in text:
        if ch == " ":
            if buf:
                tokens.append(buf)
                buf = ""
            tokens.append(" ")
        elif _WRAP_CJK_RE.match(ch):
            if buf:
                tokens.append(buf)
                buf = ""
            tokens.append(ch)
        else:
            buf += ch
    if buf:
        tokens.append(buf)
    return tokens


def _wrap_line_count(text: str, size_pt: float, bold: bool, available_width_cm: float) -> int:
    # Greedy word-wrap simulation using the actual Malgun Gothic metrics, so exact
    # row heights (below) track real content length instead of a guessed constant
    # that silently clips whenever a headline/keyword list happens to run longer.
    if not text:
        return 1
    px_size = max(8, round(size_pt * 96 / 72))
    font = _load_capture_font(px_size, bold=bold)
    draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    available_px = available_width_cm * 96 / 2.54
    lines = 1
    line_width_px = 0.0
    for token in _tokenize_for_wrap(text):
        token_width_px = draw.textlength(token, font=font)
        if line_width_px > 0 and line_width_px + token_width_px > available_px:
            if token == " ":
                continue
            lines += 1
            line_width_px = token_width_px
        else:
            line_width_px += token_width_px
    return lines


def _exact_row_height_cm(lines: int, line_height_cm: float = 0.55, margin_cm: float = 0.15, minimum_cm: float = 0.55) -> float:
    # Constants calibrated against real Word rendering (Word COM screenshot
    # comparison): 1 line needs >0.52cm and 2 lines need >1.15cm before the
    # "exact" row-height rule starts clipping 10pt Malgun Gothic bold text.
    return max(minimum_cm, margin_cm + line_height_cm * lines)


def _set_row_height(row, height_cm: float, rule: str | None = "exact"):
    # rule="exact" matches Word's Table Properties -> Row -> "Fixed" setting, per
    # explicit client request. Callers that pass variable-length text (headlines,
    # keyword lists) must compute height_cm via _wrap_line_count/_exact_row_height_cm
    # rather than a hardcoded constant, since "exact" clips content that overflows it.
    tr_pr = row._tr.get_or_add_trPr()
    tr_height = tr_pr.find(qn("w:trHeight"))
    if tr_height is None:
        tr_height = OxmlElement("w:trHeight")
        tr_pr.append(tr_height)
    tr_height.set(qn("w:val"), str(round(height_cm * 566.9291338582677)))
    if rule:
        tr_height.set(qn("w:hRule"), rule)
    elif tr_height.get(qn("w:hRule")) is not None:
        del tr_height.attrib[qn("w:hRule")]


def _strip_publication_suffix(title: str, publication: str) -> str:
    publication = publication.strip()
    if not publication:
        return title
    suffix = f" - {publication}"
    if title.endswith(suffix):
        return title[: -len(suffix)].rstrip()
    return title


def _format_cell(cell, size=10, bold=False, color=BLACK, alignment=WD_ALIGN_PARAGRAPH.LEFT):
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    _set_cell_margins(cell, top=35, start=70, bottom=35, end=70)
    for paragraph in cell.paragraphs:
        paragraph.alignment = alignment
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.line_spacing = 1.0
        for run in paragraph.runs:
            _set_run_font(run, size=size, bold=bold, color=color)


def _merged_band_row(table, text: str, fill: str, bold=True):
    row = table.add_row()
    _set_row_cant_split(row)
    _set_row_height(row, _exact_row_height_cm(1))
    cell = row.cells[0].merge(row.cells[3])
    cell.text = text
    _set_cell_shading(cell, fill)
    _format_cell(cell, size=10, bold=bold)
    return row


def _keyword_row(table, keyword_groups: list[list[str]]):
    row = table.add_row()
    _set_row_cant_split(row)
    cell = row.cells[0].merge(row.cells[3])
    cell.text = ""
    _set_cell_shading(cell, KEYWORD_GRAY)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    paragraph = cell.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    paragraph.paragraph_format.space_before = Pt(0)
    paragraph.paragraph_format.space_after = Pt(0)
    paragraph.paragraph_format.line_spacing = 1.0
    lead = paragraph.add_run("Keyword: ")
    _set_run_font(lead, size=10, bold=True, color=BLACK)
    for index, group in enumerate(keyword_groups):
        if index:
            paragraph.add_run().add_break()
        content = paragraph.add_run(" | ".join(group))
        _set_run_font(content, size=10, bold=False, color=BLACK)
    _set_cell_margins(cell, top=45, start=70, bottom=45, end=70)
    if len(keyword_groups) <= 1:
        # Single keyword group (own/competitor): 1.36cm exact/fixed, per client spec.
        _set_row_height(row, 1.36)
    else:
        # Combined ingredient+industry group: 2.89cm as a MINIMUM (Word's native
        # Table Properties -> Row -> "At least" rule, matching the client's own
        # screenshot of that dialog), not "Exact" — so it never clips a longer list.
        _set_row_height(row, 2.89, rule="atLeast")
    return row


def _article_is_ingredient(article: Article) -> bool:
    return article.category == "ingredient"


def _display_date(value: str) -> str:
    value = value.strip()
    if re.fullmatch(r"\d{2}\.\d{2}\.\d{2}\.?", value):
        return value.rstrip(".") + "."
    return value


def _add_summary_article_row(table, number: int, article: Article, keyword_pool: list[str]):
    row = table.add_row()
    _set_row_cant_split(row)
    display_title = _strip_publication_suffix(article.title, article.publication)
    matches = matched_keywords(f"{article.title} {article.body}", keyword_pool)
    tag_suffix = f" ({', '.join(matches)})" if matches else ""
    # Client-supplied exact height, no dynamic adjustment: every headline row is 0.94cm.
    _set_row_height(row, 0.94)
    values = [str(number), article.publication, _display_date(article.published_date), ""]
    for index, value in enumerate(values):
        row.cells[index].text = value
    _format_cell(row.cells[0], size=10, bold=True, alignment=WD_ALIGN_PARAGRAPH.CENTER)
    _format_cell(row.cells[1], size=10, bold=True, alignment=WD_ALIGN_PARAGRAPH.CENTER)
    _format_cell(row.cells[2], size=10, bold=True, alignment=WD_ALIGN_PARAGRAPH.CENTER)
    headline = row.cells[3]
    headline.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    paragraph = headline.paragraphs[0]
    paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
    paragraph.paragraph_format.space_before = Pt(0)
    paragraph.paragraph_format.space_after = Pt(0)
    paragraph.paragraph_format.line_spacing = 1.0
    _add_hyperlink(paragraph, display_title, article.final_url, color=LINK_TEAL, bold=True, size=10, underline=True)
    if matches:
        tag_run = paragraph.add_run(tag_suffix)
        _set_run_font(tag_run, size=10, bold=True, color=BLACK)
    _set_cell_margins(headline, top=35, start=70, bottom=35, end=70)
    return row


def _add_summary_table(
    doc: Document,
    articles: list[Article],
    brand_keywords: list[str],
    competitor_keywords: list[str],
):
    widths = [663, 1843, 1134, 6989]
    table = doc.add_table(rows=1, cols=4)
    table.alignment = 0
    table.autofit = False
    header = table.rows[0]
    for index, value in enumerate(["No.", "Publication", "Date", "Headline"]):
        header.cells[index].text = value
        _set_cell_shading(header.cells[index], BLACK)
        _format_cell(header.cells[index], size=10, bold=True, color=WHITE, alignment=WD_ALIGN_PARAGRAPH.CENTER)
    _set_row_cant_split(header)
    _set_row_height(header, _exact_row_height_cm(1))

    grouped = {
        key: [article for article in articles if article.category == key]
        for key in ("own", "competitor", "ingredient", "industry")
    }
    keyword_map = {
        "own": [brand_keywords],
        "competitor": [competitor_keywords],
    }
    number = 1
    for category in ("own", "competitor"):
        _merged_band_row(table, CATEGORY_LABELS[category], SECTION_GRAY)
        _keyword_row(table, keyword_map[category])
        category_articles = grouped[category]
        if not category_articles:
            _merged_band_row(table, "관련 기사 없음", WHITE)
            continue
        for article in category_articles:
            pool = _keyword_pool_for_category(category, brand_keywords, competitor_keywords)
            _add_summary_article_row(table, number, article, pool)
            number += 1

    _merged_band_row(table, CATEGORY_LABELS["industry"], SECTION_GRAY)
    _keyword_row(table, [INGREDIENT_KEYWORDS, INDUSTRY_KEYWORDS])
    for subgroup, category in (("성분", "ingredient"), ("업계", "industry")):
        _merged_band_row(table, subgroup, SUBGROUP_GRAY)
        subgroup_articles = grouped[category]
        if not subgroup_articles:
            _merged_band_row(table, "관련 기사 없음", WHITE)
            continue
        for article in subgroup_articles:
            pool = _keyword_pool_for_category(category, brand_keywords, competitor_keywords)
            _add_summary_article_row(table, number, article, pool)
            number += 1
    _set_table_geometry(table, widths)
    _set_table_borders(table, color=BLACK, size="4")
    return table


def _add_metadata_table(doc: Document, article: Article, report_date: str):
    table = doc.add_table(rows=5, cols=2)
    table.alignment = 0
    table.autofit = False
    table.cell(0, 0).text = "NEWS CLIPPING"
    table.cell(0, 1).text = _display_date(report_date)
    labels = ["Date", "Publication", "Page", "Circulation"]
    values = [_display_date(article.published_date), article.publication, "Online", "N/A"]
    for row_index, (label, value) in enumerate(zip(labels, values), start=1):
        table.cell(row_index, 0).text = label
        table.cell(row_index, 1).text = value
    for cell in table.rows[0].cells:
        _set_cell_shading(cell, BLACK)
    for row_index, row in enumerate(table.rows):
        _set_row_cant_split(row)
        # Client-supplied exact heights: 0.82cm for the NEWS CLIPPING banner row,
        # 0.68cm for each Date/Publication/Page/Circulation row. These fields are
        # always short, fixed-format single-line values, so no wrap safety-net needed.
        _set_row_height(row, 0.82 if row_index == 0 else 0.68)
        for col_index, cell in enumerate(row.cells):
            alignment = WD_ALIGN_PARAGRAPH.RIGHT if row_index == 0 and col_index == 1 else WD_ALIGN_PARAGRAPH.LEFT
            _format_cell(
                cell,
                size=12 if row_index == 0 else 10,
                bold=col_index == 0,
                color=WHITE if row_index == 0 else BLACK,
                alignment=alignment,
            )
    _set_table_geometry(table, [2500, 8130])
    _set_table_borders(table, color=BLACK, size="4", horizontal_only=True)
    return table


def _add_highlighted_text(paragraph, text: str, terms: list[str], size=9.5, bold=False):
    clean_terms = sorted({term.strip() for term in terms if term.strip()}, key=len, reverse=True)
    if not clean_terms:
        run = paragraph.add_run(text)
        _set_run_font(run, size=size, bold=bold, color=BLACK)
        return
    pattern = re.compile("(" + "|".join(re.escape(term) for term in clean_terms) + ")", re.IGNORECASE)
    for piece in pattern.split(text):
        if not piece:
            continue
        run = paragraph.add_run(piece)
        _set_run_font(run, size=size, bold=bold, color=BLACK)
        if pattern.fullmatch(piece):
            run.font.highlight_color = WD_COLOR_INDEX.YELLOW


def _load_capture_font(size: int, bold: bool = False):
    candidates = [
        Path(r"C:\Windows\Fonts\malgunbd.ttf" if bold else r"C:\Windows\Fonts\malgun.ttf"),
        Path(r"C:\Windows\Fonts\gulim.ttc"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def _wrap_for_image(draw: ImageDraw.ImageDraw, text: str, font, max_width: int) -> list[str]:
    lines: list[str] = []
    current = ""
    for token in re.findall(r"\S+\s*", _clean_space(text)):
        trial = current + token
        if current and draw.textbbox((0, 0), trial, font=font)[2] > max_width:
            lines.append(current.rstrip())
            current = token.lstrip()
        else:
            current = trial
    if current.strip():
        lines.append(current.rstrip())
    return lines or [""]


def _highlight_spans(line: str, terms: list[str]) -> list[tuple[int, int]]:
    clean_terms = sorted({term.strip() for term in terms if term.strip()}, key=len, reverse=True)
    if not clean_terms:
        return []
    pattern = re.compile("(" + "|".join(re.escape(term) for term in clean_terms) + ")", re.IGNORECASE)
    return [(match.start(), match.end()) for match in pattern.finditer(line)]


def _draw_line_with_highlight(draw: ImageDraw.ImageDraw, x: int, y: int, line: str, font, terms: list[str]):
    spans = _highlight_spans(line, terms)
    if spans:
        full_bbox = draw.textbbox((0, 0), line, font=font)
        top = y + full_bbox[1] - 3
        bottom = y + full_bbox[3] + 4
        for start, end in spans:
            left = x + (draw.textbbox((0, 0), line[:start], font=font)[2] if start else 0)
            right = x + draw.textbbox((0, 0), line[:end], font=font)[2]
            draw.rectangle((left - 1, top, right + 1, bottom), fill=(255, 235, 59))
    draw.text((x, y), line, font=font, fill=(24, 24, 24))


def _resolve_capture_blocks(article: Article, temp_dir: Path) -> list[dict]:
    resolved: list[dict] = []
    downloaded_urls: set[str] = set()
    for block in article.content_blocks:
        if block["type"] != "image":
            resolved.append(block)
            continue
        absolute = urllib.parse.urljoin(article.final_url, block["src"])
        if absolute in downloaded_urls:
            continue
        path = _download_image(block["src"], article.final_url, temp_dir)
        if not path:
            continue
        downloaded_urls.add(absolute)
        resolved.append({"type": "image", "path": path, "caption": block.get("caption", "")})
    if not any(block["type"] == "image" for block in resolved) and article.image_path and article.image_path.exists():
        resolved.insert(0, {"type": "image", "path": article.image_path, "caption": ""})
    if not resolved:
        resolved = [
            {"type": "text", "value": chunk}
            for chunk in re.split(r"(?:\r?\n){1,}", article.body or article.description)
            if _clean_space(chunk)
        ]
    return resolved


def _capture_article_image(
    article: Article,
    temp_dir: Path,
    capture_index: int,
    highlight_terms: list[str],
) -> list[Path]:
    width, height = 1654, 2339
    margin_x, margin_y = 140, 120
    title_font = _load_capture_font(59, bold=True)
    meta_font = _load_capture_font(28)
    body_font = _load_capture_font(36)
    caption_font = _load_capture_font(25)
    line_height = 57
    content_width = width - margin_x * 2
    pages: list[Path] = []
    page_number = 0
    canvas: Image.Image
    draw: ImageDraw.ImageDraw
    y = 0

    def new_page():
        nonlocal canvas, draw, y, page_number
        page_number += 1
        canvas = Image.new("RGB", (width, height), "white")
        draw = ImageDraw.Draw(canvas)
        y = margin_y

    def save_page():
        path = temp_dir / f"own-capture-{capture_index:03d}-{page_number:02d}.png"
        canvas.save(path, "PNG", optimize=True)
        pages.append(path)

    def draw_paragraph(text: str):
        nonlocal y
        for line in _wrap_for_image(draw, text, body_font, content_width):
            if y + line_height > height - margin_y:
                save_page()
                new_page()
            _draw_line_with_highlight(draw, margin_x, y, line, body_font, highlight_terms)
            y += line_height
        y += 29

    def draw_image_block(image_path: Path, caption: str):
        nonlocal y
        try:
            with Image.open(image_path) as original:
                picture = original.convert("RGB")
        except Exception:
            return
        max_width = min(content_width, 1300)
        max_height = min(720, height - margin_y * 2 - 220)
        picture.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
        caption_lines = _wrap_for_image(draw, caption, caption_font, content_width) if caption else []
        needed = picture.height + 24 + len(caption_lines) * 38 + 40
        if y + needed > height - margin_y and y > margin_y:
            save_page()
            new_page()
        canvas.paste(picture, ((width - picture.width) // 2, y))
        y += picture.height + 20
        for line in caption_lines:
            line_width = draw.textbbox((0, 0), line, font=caption_font)[2]
            draw.text((margin_x + (content_width - line_width) // 2, y), line, font=caption_font, fill=(120, 120, 120))
            y += 38
        y += 20

    new_page()
    for line in _wrap_for_image(draw, article.title, title_font, content_width):
        draw.text((margin_x, y), line, font=title_font, fill=(20, 20, 20))
        y += 79
    y += 13
    draw.text(
        (margin_x, y),
        f"{article.publication} · {_display_date(article.published_date)}",
        font=meta_font,
        fill=(90, 90, 90),
    )
    y += 77
    draw.line((margin_x, y, width - margin_x, y), fill=(30, 30, 30), width=4)
    y += 48

    for block in _resolve_capture_blocks(article, temp_dir):
        if block["type"] == "image":
            draw_image_block(block["path"], block.get("caption", ""))
        else:
            draw_paragraph(block["value"])
    save_page()
    return pages


def _find_browser() -> Path | None:
    candidates = [
        Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
        Path(r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
        Path(r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
    ]
    for command in ("chrome", "msedge"):
        resolved = shutil.which(command)
        if resolved:
            candidates.append(Path(resolved))
    return next((path for path in candidates if path.exists()), None)


def _extract_style_head(root, base_url: str) -> str:
    parts = []
    for link in root.xpath("//head//link[@rel='stylesheet']"):
        href = link.get("href")
        if href:
            absolute = urllib.parse.urljoin(base_url, href)
            parts.append(f'<link rel="stylesheet" href="{html_module.escape(absolute, quote=True)}">')
    for style in root.xpath("//head//style"):
        if style.text:
            parts.append(f"<style>{style.text}</style>")
    return "\n".join(parts)


def _body_class(root) -> str:
    body = root.xpath("//body")
    return _clean_space(body[0].get("class") or "") if body else ""


def _trim_node_after_markers(node):
    working = copy.deepcopy(node)
    children = [child for child in working if isinstance(child.tag, str)]
    remove_from = None
    for index, child in enumerate(children):
        text_value = _node_text(child)
        if text_value and END_MARKER_PATTERNS.search(text_value):
            remove_from = index
            break
    if remove_from is not None:
        for child in children[remove_from:]:
            working.remove(child)
    return working


def _headline_html(root, node) -> str:
    headings = root.xpath("//h1[1]")
    if not headings:
        return ""
    heading = headings[0]
    if heading is node or heading in node.iterdescendants():
        return ""
    working = copy.deepcopy(heading)
    for junk in working.xpath(".//button | .//script | .//*[contains(@class,'btn') or contains(@class,'icon') or contains(@class,'share') or contains(@class,'font')]"):
        parent = junk.getparent()
        if parent is not None:
            parent.remove(junk)
    return etree.tostring(working, method="html", encoding="unicode")


def _build_capture_document(node, root, base_url: str, highlight_terms: list[str]) -> str:
    trimmed = _trim_node_after_markers(node)
    style_head = _extract_style_head(root, base_url)
    body_class = _body_class(root)
    headline_html = _headline_html(root, node)
    node_html = headline_html + etree.tostring(trimmed, method="html", encoding="unicode")
    terms_json = json.dumps([term.strip() for term in highlight_terms if term.strip()], ensure_ascii=False)
    return f"""<!doctype html>
<html><head><meta charset="utf-8">
<base href="{html_module.escape(base_url, quote=True)}">
{style_head}
<style>
html,body{{margin:0 !important;background:#fff !important;}}
#__capture_root__{{max-width:920px;margin:0 auto;padding:28px 20px;box-sizing:border-box}}
#__capture_root__ img{{max-width:100% !important;height:auto !important}}
mark.__vb_hl__{{background:#ffeb3b;color:inherit;padding:0}}
/* Defeat scroll/JS-triggered reveal animations - we never scroll or run the
   page's own scripts, so content gated on them would otherwise stay invisible. */
#__capture_root__, #__capture_root__ * {{
  opacity: 1 !important;
  visibility: visible !important;
  transform: none !important;
  animation: none !important;
  transition: none !important;
  filter: none !important;
  clip-path: none !important;
  max-height: none !important;
}}
</style>
</head>
<body class="{html_module.escape(body_class, quote=True)}">
<div id="__capture_root__">{node_html}</div>
<script>
(function(){{
  // Some sites style article text to sit on a dark background (color close to
  // white). We force the page background to white, so that text would otherwise
  // render invisibly. Detect near-white text sitting on a near-white background
  // and darken it so it stays readable.
  function luminance(rgb) {{
    var m = rgb && rgb.match(/\\d+/g);
    if (!m) return 0;
    return (0.299 * m[0] + 0.587 * m[1] + 0.114 * m[2]) / 255;
  }}
  var root = document.getElementById('__capture_root__');
  var all = root.querySelectorAll('*');
  for (var i = 0; i < all.length; i++) {{
    var el = all[i];
    var style = getComputedStyle(el);
    if (luminance(style.color) > 0.82) {{
      var bg = style.backgroundColor;
      var bgLum = (!bg || bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent') ? 1 : luminance(bg);
      if (bgLum > 0.7) {{
        el.style.setProperty('color', '#1a1a1a', 'important');
      }}
    }}
  }}
}})();
(function(){{
  var terms = {terms_json};
  if (!terms.length) return;
  var escaped = terms.map(function(t){{return t.replace(/[.*+?^${{}}()|[\\]\\\\]/g,'\\\\$&');}});
  var re = new RegExp('(' + escaped.join('|') + ')', 'gi');
  var root = document.getElementById('__capture_root__');
  var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
  var nodes = [];
  var n;
  while ((n = walker.nextNode())) {{ nodes.push(n); }}
  nodes.forEach(function(node){{
    if (!node.nodeValue || !re.test(node.nodeValue)) return;
    re.lastIndex = 0;
    var span = document.createElement('span');
    span.innerHTML = node.nodeValue.replace(re, '<mark class="__vb_hl__">$1</mark>');
    node.parentNode.replaceChild(span, node);
  }});
}})();
</script>
</body></html>"""


def _build_full_page_document(markup: str, base_url: str, highlight_terms: list[str]) -> str:
    # Used for the live-page fallback: keep the real page's own HTML/CSS/scripts
    # intact (so it renders exactly as the real site does) and just inject a <base>
    # so relative URLs resolve, plus a script that darkens near-invisible text and
    # applies the same yellow keyword highlight as the clean capture path - without
    # this, live-page fallback captures would show no highlight at all.
    terms_json = json.dumps([term.strip() for term in highlight_terms if term.strip()], ensure_ascii=False)
    base_tag = f'<base href="{html_module.escape(base_url, quote=True)}">'
    script = f"""<script>
(function(){{
  function luminance(rgb) {{
    var m = rgb && rgb.match(/\\d+/g);
    if (!m) return 0;
    return (0.299 * m[0] + 0.587 * m[1] + 0.114 * m[2]) / 255;
  }}
  var all = document.body.querySelectorAll('*');
  for (var i = 0; i < all.length; i++) {{
    var el = all[i];
    var style = getComputedStyle(el);
    if (luminance(style.color) > 0.82) {{
      var bg = style.backgroundColor;
      var bgLum = (!bg || bg === 'rgba(0, 0, 0, 0)' || bg === 'transparent') ? 1 : luminance(bg);
      if (bgLum > 0.7) {{
        el.style.setProperty('color', '#1a1a1a', 'important');
      }}
    }}
  }}
  var terms = {terms_json};
  if (!terms.length) return;
  var escaped = terms.map(function(t){{return t.replace(/[.*+?^${{}}()|[\\]\\\\]/g,'\\\\$&');}});
  var re = new RegExp('(' + escaped.join('|') + ')', 'gi');
  var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
  var nodes = [];
  var n;
  while ((n = walker.nextNode())) {{ nodes.push(n); }}
  nodes.forEach(function(node){{
    if (!node.nodeValue || !re.test(node.nodeValue)) return;
    if (node.parentNode && node.parentNode.closest('script,style,noscript')) return;
    re.lastIndex = 0;
    var span = document.createElement('span');
    span.innerHTML = node.nodeValue.replace(re, '<mark style="background:#ffeb3b;color:inherit;padding:0">$1</mark>');
    node.parentNode.replaceChild(span, node);
  }});
}})();
</script>"""
    lower = markup.lower()
    head_idx = lower.find("<head")
    if head_idx != -1:
        insert_at = markup.find(">", head_idx) + 1
        markup = markup[:insert_at] + base_tag + markup[insert_at:]
    else:
        markup = base_tag + markup
    body_close_idx = markup.lower().rfind("</body>")
    if body_close_idx != -1:
        markup = markup[:body_close_idx] + script + markup[body_close_idx:]
    else:
        markup += script
    return markup


def _find_safe_cut(gray_pixels, width: int, target_y: int, min_y: int, threshold: int = 248, stride: int = 3) -> int:
    for y in range(target_y, max(min_y, target_y - 220), -1):
        blank = True
        for x in range(0, width, stride):
            if gray_pixels[x, y] < threshold:
                blank = False
                break
        if blank:
            return y
    return target_y


def _slice_tall_screenshot(shot_path: Path, temp_dir: Path, capture_index: int) -> list[Path]:
    with Image.open(shot_path) as source:
        image = source.convert("RGB")
    gray = image.convert("L")
    mask = gray.point(lambda value: 255 if value < 250 else 0)
    box = mask.getbbox()
    if not box:
        return []
    top = max(0, box[1] - 10)
    bottom = min(image.height, box[3] + 20)
    width = image.width
    gray_px = gray.load()
    page_height = int(width * 1.5)
    min_segment_height = max(250, int(width * 0.25))

    bounds = [top]
    y = top
    while y < bottom:
        target = min(y + page_height, bottom)
        if target < bottom:
            safe = _find_safe_cut(gray_px, width, target, y + int(page_height * 0.6))
            if safe > y:
                target = safe
        bounds.append(target)
        y = target

    # Merge any segment shorter than min_segment_height into a neighbor so a short
    # trailing/leading fragment (e.g. one leftover line) never becomes its own
    # near-empty page that renders as a barely-visible sliver in Word.
    segments = list(zip(bounds[:-1], bounds[1:]))
    merged: list[tuple[int, int]] = []
    for start, end in segments:
        if merged and end - start < min_segment_height:
            merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))
    if len(merged) >= 2 and merged[0][1] - merged[0][0] < min_segment_height:
        merged[1] = (merged[0][0], merged[1][1])
        merged.pop(0)

    pages: list[Path] = []
    for index, (start, end) in enumerate(merged, start=1):
        chunk = image.crop((0, start, width, end))
        path = temp_dir / f"own-capture-{capture_index:03d}-{index:02d}.png"
        chunk.save(path, "PNG", optimize=True)
        pages.append(path)
    return pages


def _run_chrome_screenshot(
    browser: Path,
    target: str,
    temp_dir: Path,
    capture_index: int,
    attempt: str,
    max_pages: int | None = None,
) -> list[Path]:
    shot_path = temp_dir / f"own-capture-{capture_index:03d}-{attempt}-full.png"
    profile_path = temp_dir / f"browser-profile-{capture_index:03d}-{attempt}"
    profile_path.mkdir(parents=True, exist_ok=True)
    width = 1000
    command = [
        str(browser),
        "--headless=new",
        "--disable-gpu",
        "--no-sandbox",
        "--disable-extensions",
        "--disable-sync",
        "--hide-scrollbars",
        "--force-device-scale-factor=1.5",
        f"--window-size={width},20000",
        "--virtual-time-budget=8000",
        f"--user-data-dir={profile_path}",
        f"--screenshot={shot_path}",
        target,
    ]
    completed = subprocess.run(
        command,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=60,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if completed.returncode != 0 or not shot_path.exists() or shot_path.stat().st_size < 3_000:
        return []
    pages = _slice_tall_screenshot(shot_path, temp_dir, capture_index)
    if max_pages is not None and len(pages) > max_pages:
        # Real article text sits at the top of the page; anything past this many
        # slices is almost always a "related/popular news" or ad section below it.
        for stale_path in pages[max_pages:]:
            stale_path.unlink(missing_ok=True)
        pages = pages[:max_pages]
    return pages


def _total_capture_height(pages: list[Path]) -> int:
    total = 0
    for path in pages:
        with Image.open(path) as image:
            total += image.height
    return total


def _capture_with_browser(
    article: Article,
    temp_dir: Path,
    capture_index: int,
    highlight_terms: list[str],
) -> list[Path]:
    browser = _find_browser()
    if not browser:
        raise RuntimeError("Chrome 또는 Edge 브라우저를 찾을 수 없습니다.")
    raw, headers, final_url = _fetch_bytes(article.final_url)
    markup = _decode_body(raw, headers)
    parser = html.HTMLParser(encoding="utf-8", recover=True)
    root = html.fromstring(markup.encode("utf-8", "ignore"), parser=parser, base_url=final_url)
    node = _select_article_node(root)

    if node is not None and len(_node_text(node)) >= 120:
        document = _build_capture_document(node, root, final_url, highlight_terms)
        html_path = temp_dir / f"own-capture-{capture_index:03d}.html"
        html_path.write_text(document, encoding="utf-8")
        pages = _run_chrome_screenshot(browser, html_path.as_uri(), temp_dir, capture_index, "clean")
        if pages and _total_capture_height(pages) >= 400:
            return pages

    # Reconstructed-page capture came out empty or unusably thin (commonly a
    # JS-rendered page whose content never appears in the raw HTML, or text styled
    # to sit on a dark background that disappears against our forced white page) -
    # fall back to screenshotting the real live page directly. This keeps nav/ads
    # visible but still captures real, visible content.
    # Bound the live-page fallback to roughly how much space the real article text
    # needs, so slicing doesn't drift past it into "related/popular news" sections.
    known_length = len(article.body) or (len(_node_text(node)) if node is not None else 0)
    live_max_pages = max(1, min(4, (known_length // 550) + 1))
    live_document = _build_full_page_document(markup, final_url, highlight_terms)
    live_html_path = temp_dir / f"own-capture-{capture_index:03d}-live.html"
    live_html_path.write_text(live_document, encoding="utf-8")
    pages = _run_chrome_screenshot(browser, live_html_path.as_uri(), temp_dir, capture_index, "live", max_pages=live_max_pages)
    if not pages:
        raise RuntimeError("캡처된 이미지가 비어 있습니다.")
    return pages


def capture_own_article(
    article: Article,
    temp_dir: Path,
    capture_index: int,
    brand_keywords: list[str],
) -> list[Path]:
    if len(_clean_space(article.body or article.description)) < 120:
        article.capture_error = article.error or "기사 본문을 충분히 수집하지 못했습니다."
        return []
    try:
        return _capture_with_browser(article, temp_dir, capture_index, brand_keywords)
    except Exception as browser_error:
        try:
            pages = _capture_article_image(article, temp_dir, capture_index, brand_keywords)
            if pages:
                article.capture_error = f"실제 화면 캡처 대신 기본 이미지 캡처 사용: {browser_error}"
            return pages
        except Exception as fallback_error:
            article.capture_error = f"{browser_error}; 기본 이미지 캡처도 실패: {fallback_error}"
            return []


def _add_article_clipping(doc: Document, article: Article, report_date: str):
    doc.add_page_break()
    _add_metadata_table(doc, article, report_date)
    if article.capture_paths:
        _new_paragraph(doc, after=0, before=0, size=10)
        for index, capture_path in enumerate(article.capture_paths):
            if index:
                doc.add_page_break()
            paragraph = doc.add_paragraph()
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.paragraph_format.space_before = Pt(0)
            paragraph.paragraph_format.space_after = Pt(0)
            with Image.open(capture_path) as image:
                ratio = image.height / max(image.width, 1)
            max_width = 5.35 if index == 0 else 6.35
            max_height = 7.45 if index == 0 else 9.45
            width = min(max_width, max_height / max(ratio, 0.01))
            shape = paragraph.add_run().add_picture(str(capture_path), width=Inches(width))
            shape._inline.docPr.set("descr", f"{article.title} 전문 캡처 {index + 1}")
        return

    if article.capture_error or article.error:
        warning = _new_paragraph(
            doc,
            f"전문 캡처 확인 필요: {article.capture_error or article.error}",
            size=9,
            bold=True,
            color=ALERT_RED,
            after=8,
        )
        warning.paragraph_format.keep_with_next = True

    fallback = _new_paragraph(doc, after=5)
    _add_hyperlink(fallback, article.title, article.final_url, color=LINK_TEAL, bold=True, size=11)


def _safe_filename(value: str) -> str:
    value = re.sub(r"[<>:\"/\\|?*]", "_", value.strip())
    value = re.sub(r"\s+", " ", value).strip(" .")
    return value or "REPORT"


def _numbered_output_path(preferred_path: Path) -> Path:
    for number in range(2, 10_000):
        candidate = preferred_path.with_name(f"{preferred_path.stem} ({number}){preferred_path.suffix}")
        if not candidate.exists():
            return candidate
    raise OSError("같은 날짜의 보고서 파일이 너무 많아 새 파일명을 만들 수 없습니다.")


def _select_output_path(preferred_path: Path) -> Path:
    if not preferred_path.exists():
        return preferred_path
    try:
        with preferred_path.open("r+b"):
            pass
        return preferred_path
    except (PermissionError, OSError):
        return _numbered_output_path(preferred_path)


def _parse_report_date(value: str) -> tuple[date, str, str]:
    normalized = value.strip().replace(".", "-").replace("/", "-")
    parsed = datetime.strptime(normalized, "%Y-%m-%d").date()
    return parsed, parsed.strftime("%y.%m.%d"), parsed.strftime("%y%m%d")


def _prune_unused_document_relationships(path: Path):
    with zipfile.ZipFile(path, "r") as source:
        document_xml = source.read("word/document.xml")
        rels_xml = source.read("word/_rels/document.xml.rels")
        document_root = etree.fromstring(document_xml)
        used_ids = set(
            document_root.xpath(
                "//@r:id | //@r:embed | //@r:link",
                namespaces={"r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"},
            )
        )
        rels_root = etree.fromstring(rels_xml)
        changed = False
        for relationship in list(rels_root):
            rel_type = relationship.get("Type", "")
            rel_id = relationship.get("Id", "")
            if rel_id not in used_ids and rel_type.endswith(("/hyperlink", "/image")):
                rels_root.remove(relationship)
                changed = True
        if not changed:
            return
        revised_rels = etree.tostring(rels_root, xml_declaration=True, encoding="UTF-8", standalone=True)
        temp_path = path.with_name(path.stem + ".package-cleanup.docx")
        with zipfile.ZipFile(temp_path, "w") as destination:
            for info in source.infolist():
                data = revised_rels if info.filename == "word/_rels/document.xml.rels" else source.read(info.filename)
                destination.writestr(info, data)
    temp_path.replace(path)


EMPTY_NUMBERING_XML = (
    b'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n'
    b'<w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"/>'
)


def _restore_preserve_only_parts(path: Path, reference_path: Path):
    exact_parts = {
        "word/header1.xml",
        "word/_rels/header1.xml.rels",
        "word/styles.xml",
        "word/theme/theme1.xml",
        "word/fontTable.xml",
        "word/settings.xml",
        "word/footnotes.xml",
        "word/endnotes.xml",
        "word/webSettings.xml",
    }
    with zipfile.ZipFile(reference_path, "r") as reference:
        reference_names = set(reference.namelist())
        exact_parts.update(name for name in reference_names if name.startswith("customXml/"))
        with zipfile.ZipFile(path, "r") as source:
            temp_path = path.with_name(path.stem + ".preserve-only.docx")
            with zipfile.ZipFile(temp_path, "w") as destination:
                for info in source.infolist():
                    if info.filename == "word/numbering.xml":
                        # We never use numbered/bulleted lists anywhere in the
                        # generated content, but the reference template's own
                        # numbering.xml still defines a real bullet glyph. Some
                        # inherited style in that template references it just
                        # enough that Word intermittently renders a stray bullet
                        # near the title depending on zoom - dropping the
                        # definitions entirely removes the glyph it would draw.
                        data = EMPTY_NUMBERING_XML
                    elif info.filename in exact_parts and info.filename in reference_names:
                        data = reference.read(info.filename)
                    else:
                        data = source.read(info.filename)
                    destination.writestr(info, data)
    temp_path.replace(path)


def create_report_docx(
    articles: list[Article],
    output_path: Path,
    reference_path: Path,
    client_code: str,
    brand_keywords: list[str],
    competitor_keywords: list[str],
    report_date_input: str,
    preserve_reference_banner: bool,
    temp_dir: Path,
) -> Path:
    parsed_date, report_date, filename_date = _parse_report_date(report_date_input)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(reference_path, output_path)
    doc = Document(output_path)
    _clear_document_body(doc)
    section = doc.sections[0]
    section.orientation = WD_ORIENT.PORTRAIT
    section.page_width = Inches(8.2677)
    section.page_height = Inches(11.6929)
    section.top_margin = Inches(0.5)
    section.bottom_margin = Inches(0.5)
    section.left_margin = Inches(0.5)
    section.right_margin = Inches(0.5)
    del preserve_reference_banner, temp_dir

    title = _new_paragraph(doc, "Daily Monitoring Report", size=20, bold=True, color=BLACK)
    title.paragraph_format.space_after = None
    title.paragraph_format.line_spacing = None
    _set_paragraph_bottom_border(title, color="auto", size="6", space="12")
    subtitle = _new_paragraph(
        doc,
        f"News Clipping List ({report_date}.)",
        size=12,
        bold=True,
        color=DARK_GRAY,
    )
    subtitle.paragraph_format.space_after = None
    subtitle.paragraph_format.line_spacing = None

    _add_summary_table(doc, articles, brand_keywords, competitor_keywords)
    for article in articles:
        if article.category == "own":
            _add_article_clipping(doc, article, report_date)

    doc.core_properties.title = f"Daily Monitoring Report {client_code} {filename_date}"
    doc.core_properties.subject = "News Clipping"
    doc.core_properties.comments = "기사 링크 자동 생성"
    doc.save(output_path)
    _prune_unused_document_relationships(output_path)
    _restore_preserve_only_parts(output_path, reference_path)
    return output_path


def verify_report(path: Path, articles: list[Article]) -> dict:
    if not path.exists() or path.stat().st_size < 20_000:
        raise ValueError("생성된 Word 파일이 없거나 크기가 비정상적으로 작습니다.")
    doc = Document(path)
    text_parts = [paragraph.text for paragraph in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            text_parts.extend(cell.text for cell in row.cells)
    all_text = "\n".join(text_parts)
    forbidden = ["25XXXX", "오아시스마켓", "폭스바겐", "VWFSK", "News Clipping List (25.05.22)"]
    leftovers = [value for value in forbidden if value in all_text]
    if leftovers:
        raise ValueError(f"샘플 문구가 남아 있습니다: {', '.join(leftovers)}")
    own_articles = [article for article in articles if article.category == "own"]
    expected_tables = len(own_articles) + 1
    if len(doc.tables) != expected_tables:
        raise ValueError(f"표 개수가 맞지 않습니다: {len(doc.tables)} / {expected_tables}")
    if "Company News" not in all_text or "Industry News" not in all_text:
        raise ValueError("바이탈뷰티 요약표의 필수 구역이 없습니다.")
    if all_text.count("NEWS CLIPPING") != len(own_articles):
        raise ValueError("자사 기사별 NEWS CLIPPING 메타정보 수가 맞지 않습니다.")
    expected_capture_articles = sum(1 for article in own_articles if article.capture_paths)
    if len(doc.inline_shapes) < expected_capture_articles:
        raise ValueError("자사 기사 전문 캡처 이미지가 문서에 충분히 삽입되지 않았습니다.")
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        if "word/header1.xml" not in names or "word/media/image1.png" not in names:
            raise ValueError("바이탈뷰티 상단 배너가 문서에 없습니다.")
        rels = etree.fromstring(archive.read("word/_rels/document.xml.rels"))
        hyperlinks = [
            node for node in rels
            if (node.get("Type") or "").endswith("/hyperlink")
        ]
        app_root = etree.fromstring(archive.read("docProps/app.xml"))
        pages = ""
        for child in app_root:
            if child.tag.endswith("}Pages"):
                pages = child.text or ""
    return {
        "tables": len(doc.tables),
        "hyperlinks": len(hyperlinks),
        "inline_shapes": len(doc.inline_shapes),
        "own_articles": len(own_articles),
        "own_capture_pages": sum(len(article.capture_paths) for article in own_articles),
        "capture_failures": sum(1 for article in own_articles if not article.capture_paths),
        "reported_pages": pages,
        "size": path.stat().st_size,
    }


def generate_report(
    raw_links: str,
    client_code: str,
    brand_keywords: list[str],
    competitor_keywords: list[str],
    report_date_input: str,
    output_directory: Path,
    reference_path: Path,
    preserve_reference_banner: bool = True,
    progress: Callable[[str], None] | None = None,
) -> tuple[Path, list[Article], dict]:
    progress = progress or (lambda message: None)
    inputs = parse_link_input(raw_links)
    if not inputs:
        raise ValueError("유효한 기사 링크가 없습니다.")
    parsed_date, _, filename_date = _parse_report_date(report_date_input)
    del parsed_date
    with tempfile.TemporaryDirectory(prefix="daily-monitoring-") as temp_name:
        temp_dir = Path(temp_name)
        articles: list[Article] = []
        for index, item in enumerate(inputs, start=1):
            progress(f"[{index}/{len(inputs)}] 기사 정보를 불러오는 중... {item.url}")
            article = fetch_article(item, brand_keywords, competitor_keywords, temp_dir)
            articles.append(article)
            if article.error:
                progress(f"  - 자동 수집 제한: {article.error}")
            else:
                progress(f"  - {article.publication} / {article.title[:70]}")
        own_articles = [article for article in articles if article.category == "own"]
        for index, article in enumerate(own_articles, start=1):
            progress(f"[{index}/{len(own_articles)}] 자사 기사 전문을 이미지로 캡처하는 중... {article.title[:55]}")
            article.capture_paths = capture_own_article(article, temp_dir, index, brand_keywords)
            if article.capture_paths:
                progress(f"  - 전문 캡처 {len(article.capture_paths)}페이지 완료")
            else:
                progress(f"  - 전문 캡처 확인 필요: {article.capture_error}")
        safe_client = _safe_filename(client_code)
        preferred_output_path = output_directory / f"Daily Monitoring Report_{safe_client}_{filename_date}.docx"
        output_path = _select_output_path(preferred_output_path)
        if output_path != preferred_output_path:
            progress(f"같은 날짜의 Word 파일이 열려 있어 새 이름으로 저장합니다: {output_path.name}")
        progress("Word 보고서를 구성하는 중...")
        try:
            create_report_docx(
                articles=articles,
                output_path=output_path,
                reference_path=reference_path,
                client_code=client_code,
                brand_keywords=brand_keywords,
                competitor_keywords=competitor_keywords,
                report_date_input=report_date_input,
                preserve_reference_banner=preserve_reference_banner,
                temp_dir=temp_dir,
            )
        except PermissionError:
            if output_path != preferred_output_path:
                raise
            output_path = _numbered_output_path(preferred_output_path)
            progress(f"기존 Word 파일을 덮어쓸 수 없어 새 이름으로 저장합니다: {output_path.name}")
            create_report_docx(
                articles=articles,
                output_path=output_path,
                reference_path=reference_path,
                client_code=client_code,
                brand_keywords=brand_keywords,
                competitor_keywords=competitor_keywords,
                report_date_input=report_date_input,
                preserve_reference_banner=preserve_reference_banner,
                temp_dir=temp_dir,
            )
        progress("문서 구조를 확인하는 중...")
        verification = verify_report(output_path, articles)
        progress(f"완료: {output_path}")
        return output_path, articles, verification
