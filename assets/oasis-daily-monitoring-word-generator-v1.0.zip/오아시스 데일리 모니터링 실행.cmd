@echo off
setlocal

set "APP_DIR=%~dp0"
set "PY="
set "PYW="

rem 0) Files extracted from a zip that was downloaded/received via chat, email,
rem    or a shared drive get tagged by Windows as "from the internet", which can
rem    silently block scripts from running with no visible error at all. Strip
rem    that tag from every file in this folder so nothing gets blocked.
powershell -NoProfile -Command "Get-ChildItem -Path '%APP_DIR%' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue" >nul 2>nul

rem 1) If this PC still has the Codex-bundled Python (with packages already installed), reuse it.
set "CODEX_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
set "CODEX_PYW=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\pythonw.exe"
if exist "%CODEX_PY%" if exist "%CODEX_PYW%" (
  set "PY=%CODEX_PY%"
  set "PYW=%CODEX_PYW%"
)

rem 2) Otherwise, use any Python already installed on this PC.
if not defined PY (
  for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%P"
)
if not defined PY (
  for /f "delims=" %%P in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "PY=%%P"
)
if not defined PY (
  echo Python was not found on this PC.
  echo Please install Python 3.11 or later from https://www.python.org/downloads/
  echo During setup, check the box "Add python.exe to PATH", then run this again.
  pause
  exit /b 1
)
if not defined PYW (
  for %%F in ("%PY%") do set "PYW=%%~dpFpythonw.exe"
  if not exist "%PYW%" set "PYW=%PY%"
)

rem 3) Make sure the required components are installed, installing them automatically if missing.
"%PY%" -c "import lxml, PIL, docx, certifi" 1>nul 2>nul
if errorlevel 1 (
  echo Installing required components. Please wait a moment...
  "%PY%" -m pip install --quiet --disable-pip-version-check lxml Pillow python-docx certifi
  if errorlevel 1 (
    echo Failed to install required components. Check your internet connection and try again.
    pause
    exit /b 1
  )
)

start "" "%PYW%" "%APP_DIR%daily_monitoring_app.pyw"
endlocal
