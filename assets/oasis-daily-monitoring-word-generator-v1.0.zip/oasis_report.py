"""오아시스마켓 데일리 모니터링 Word 생성기.

링크를 붙여 넣으면 기사를 읽어와 분류하고
`Daily Monitoring Report_OASIS_YYMMDD.docx` 를 만든다.

기사 수집·본문 추출·요약은 `article_core`(바이탈뷰티 생성기와 같은 엔진)를 쓴다.
이 파일은 오아시스 고유의 분류 체계와 문서 서식만 담당한다.
"""
from __future__ import annotations

import re
import shutil
import tempfile
from dataclasses import dataclass
from datetime import date
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt

import article_core as core

BASE_DIR = Path(__file__).resolve().parent
REFERENCE_DOCX = BASE_DIR / "assets" / "reference_oasis.docx"

GREEN = "196B24"
DARK_GRAY = "404040"
BLACK = "000000"

# ── 분류 키워드 ────────────────────────────────────────────────
# 출처: (피알원) 오아시스마켓 데일리 모니터링 관련 키워드 제안_250103.docx
OWN_KEYWORDS = [
    "오아시스마켓", "오아시스루트", "오아시스알파", "킴스오아시스",
    "소비더마켓", "지어소프트", "오아시스", "티몬", "TMON",
]
COMPETITOR_KEYWORDS = [
    "컬리", "마켓컬리", "쿠팡", "G마켓", "지마켓", "쓱닷컴", "SSG닷컴",
    "네이버쇼핑", "11번가",
]
INDUSTRY_KEYWORDS = [
    "유통", "이커머스", "새벽배송", "익일배송", "당일배송",
    "스마트물류", "퀵커머스", "온라인 장보기", "온라인장보기",
]

MAJOR_SECTIONS = [
    ("own", "자사 관련 뉴스"),
    ("competitor", "경쟁사 관련 뉴스"),
    ("industry", "업계 관련 뉴스"),
]

# 자사 섹션 안에서 쓰는 소분류. 실제 보고서에 나오는 순서대로.
OWN_SUBGROUPS = [
    "[보도자료]",
    "[오아시스]",
    "[티몬]",
    "[오아시스/티몬]",
    "[단순언급_오아시스]",
    "[단순언급_티몬]",
]

MAJOR_MARKERS = {
    "자사": "own", "자사 관련 뉴스": "own", "자사 관련 보도": "own",
    "경쟁사": "competitor", "경쟁사 관련 뉴스": "competitor",
    "경쟁사 관련 보도": "competitor",
    "업계": "industry", "업계 관련 뉴스": "industry", "업계 관련 보도": "industry",
}

# 소분류 마커는 자사 섹션까지 함께 지정한다.
SUBGROUP_MARKERS = {
    "보도자료": "[보도자료]",
    "오아시스": "[오아시스]",
    "티몬": "[티몬]",
    "오아시스/티몬": "[오아시스/티몬]",
    "단순언급_오아시스": "[단순언급_오아시스]",
    "단순언급오아시스": "[단순언급_오아시스]",
    "단순언급_티몬": "[단순언급_티몬]",
    "단순언급티몬": "[단순언급_티몬]",
}


@dataclass
class OasisLink:
    url: str
    major: str | None = None
    subgroup: str | None = None


@dataclass
class OasisItem:
    url: str
    title: str
    publication: str
    summary: str
    major: str
    subgroup: str | None
    error: str = ""


def parse_input(raw: str) -> list[OasisLink]:
    """링크 입력을 읽는다.

    한 줄에 `[오아시스]` 처럼 마커만 있으면 그 아래 링크들에 적용된다.
    `오아시스 | https://...` 처럼 한 줄에 같이 써도 된다.
    마커가 없으면 본문 키워드로 자동 분류한다.
    """
    links: list[OasisLink] = []
    seen: set[str] = set()
    major: str | None = None
    subgroup: str | None = None

    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue

        marker = re.sub(r"[\[\]#:*]", "", line).strip()
        if "http" not in line and marker in MAJOR_MARKERS:
            major = MAJOR_MARKERS[marker]
            subgroup = None
            continue
        if "http" not in line and marker in SUBGROUP_MARKERS:
            major = "own"
            subgroup = SUBGROUP_MARKERS[marker]
            continue

        line_major, line_sub = major, subgroup
        prefix = re.match(r"^([^|]{1,20})\s*\|\s*(.+)$", line)
        if prefix:
            token = re.sub(r"[\[\]#:*]", "", prefix.group(1)).strip()
            if token in MAJOR_MARKERS:
                line_major, line_sub = MAJOR_MARKERS[token], None
                line = prefix.group(2)
            elif token in SUBGROUP_MARKERS:
                line_major, line_sub = "own", SUBGROUP_MARKERS[token]
                line = prefix.group(2)

        for match in re.findall(r"https?://[^\s<>\"']+", line):
            url = core._sanitize_url(match)
            if url and url not in seen:
                seen.add(url)
                links.append(OasisLink(url=url, major=line_major, subgroup=line_sub))
    return links


def classify(text: str) -> str:
    """마커가 없을 때 본문으로 자사/경쟁사/업계를 고른다."""
    lowered = text.lower()

    def hit(words):
        return any(w.lower() in lowered for w in words)

    if hit(OWN_KEYWORDS):
        return "own"
    if hit(COMPETITOR_KEYWORDS):
        return "competitor"
    if hit(INDUSTRY_KEYWORDS):
        return "industry"
    return "industry"


OASIS_WORDS = ["오아시스마켓", "오아시스루트", "오아시스알파", "킴스오아시스", "오아시스"]
TMON_WORDS = ["티몬", "tmon"]

# 본문에서 이만큼 미만으로 언급되고 제목에도 없으면 단순 언급으로 본다.
MENTION_THRESHOLD = 3


def _count(text: str, words) -> int:
    lowered = text.lower()
    return sum(lowered.count(w.lower()) for w in words)


def default_subgroup(title: str, body: str) -> str:
    """자사 기사의 소분류를 추정한다. 확정이 아니라 초안이다."""
    haystack = f"{title} {body}"
    oasis_hits = _count(haystack, OASIS_WORDS)
    tmon_hits = _count(haystack, TMON_WORDS)
    in_title_oasis = _count(title, OASIS_WORDS) > 0
    in_title_tmon = _count(title, TMON_WORDS) > 0

    if oasis_hits and tmon_hits and (in_title_oasis or in_title_tmon):
        return "[오아시스/티몬]"

    # 어느 쪽이 더 중심인지 고른다.
    if tmon_hits > oasis_hits:
        return "[티몬]" if (in_title_tmon or tmon_hits >= MENTION_THRESHOLD) else "[단순언급_티몬]"
    if oasis_hits:
        return "[오아시스]" if (in_title_oasis or oasis_hits >= MENTION_THRESHOLD) else "[단순언급_오아시스]"
    if tmon_hits:
        return "[단순언급_티몬]"
    return "[오아시스]"


def _publication_names(publication: str):
    names = set()
    for name in (publication or "").strip(), (publication or "").split("(")[0].strip():
        if name:
            names.add(name)
    return names


def clean_title(title: str, publication: str) -> str:
    """제목에 붙은 매체명 꼬리표를 떼어낸다.

    `제목 - 매체명` 처럼 뒤에 붙는 것과 `[매체명] 제목` 처럼 앞에 붙는 것 둘 다 처리한다.
    """
    title = (title or "").strip()
    for name in _publication_names(publication):
        title = re.sub(r"\s*[-–—|:·]\s*" + re.escape(name) + r"\s*$", "", title).strip()
        title = re.sub(r"^\[\s*" + re.escape(name) + r"\s*\]\s*", "", title).strip()
    return title


def clean_summary(summary: str, title: str, publication: str) -> str:
    """요약문 앞에 붙는 군더더기를 걷어낸다.

    매체 태그와, 본문이 제목을 그대로 다시 읊는 경우를 지운다.
    """
    summary = (summary or "").strip()
    if not summary:
        return ""
    for name in _publication_names(publication):
        summary = re.sub(r"^\[\s*" + re.escape(name) + r"\s*\]\s*", "", summary).strip()

    # 본문 첫머리가 제목을 그대로 반복하면 그 부분만 덜어낸다.
    stripped_title = title.strip()
    if stripped_title and summary.startswith(stripped_title):
        remainder = summary[len(stripped_title):].lstrip(" .·…-–—|")
        if len(remainder) >= 40:
            summary = remainder
    return summary.strip()


def collect(links, progress=None, temp_dir: Path | None = None):
    items = []
    total = len(links)
    scratch = Path(temp_dir) if temp_dir else Path(tempfile.mkdtemp(prefix="oasis_"))
    scratch.mkdir(parents=True, exist_ok=True)
    for index, link in enumerate(links, start=1):
        if progress:
            progress(index, total, link.url)
        article = core.fetch_article(
            core.InputLink(url=link.url, category_override=None),
            brand_keywords=OWN_KEYWORDS,
            competitor_keywords=COMPETITOR_KEYWORDS,
            temp_dir=scratch,
        )
        title = clean_title(article.title or "", article.publication or "")
        body = " ".join([article.description or "", article.body or ""])
        major = link.major or classify(f"{title} {body}")
        subgroup = link.subgroup
        if major == "own" and not subgroup:
            subgroup = default_subgroup(title, body)
        items.append(OasisItem(
            url=article.final_url or link.url,
            title=title or "(제목을 읽지 못했습니다)",
            publication=article.publication or "",
            summary=clean_summary(article.summary or "", title, article.publication or ""),
            major=major,
            subgroup=subgroup,
            error=article.error,
        ))
    return items


def _para(doc, text="", *, style=None, size=None, bold=None, color=None, align=None,
          space_after=4, space_before=0):
    paragraph = doc.add_paragraph(style=style) if style else doc.add_paragraph()
    if text:
        run = paragraph.add_run(text)
        core._set_run_font(run, size=size, bold=bold, color=color)
    if align is not None:
        paragraph.alignment = align
    paragraph.paragraph_format.space_after = Pt(space_after)
    paragraph.paragraph_format.space_before = Pt(space_before)
    return paragraph


def hyperlink_style_id(doc) -> str | None:
    """문서에 정의된 하이퍼링크 문자 스타일의 id를 찾는다.

    한글 Word 는 이 스타일을 `a6` 같은 이름으로 저장한다.
    색을 코드에 박지 않고 원본 스타일을 그대로 쓰기 위해 id를 찾아 붙인다.
    """
    for style in doc.styles.element.findall(qn("w:style")):
        if style.get(qn("w:type")) != "character":
            continue
        name = style.find(qn("w:name"))
        if name is not None and name.get(qn("w:val")) == "Hyperlink":
            return style.get(qn("w:styleId"))
    return None


def _add_styled_hyperlink(paragraph, text: str, url: str, style_id: str | None):
    """원본과 같은 하이퍼링크 서식(색·밑줄)으로 링크를 넣는다."""
    rel_id = paragraph.part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), rel_id)

    run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    if style_id:
        r_style = OxmlElement("w:rStyle")
        r_style.set(qn("w:val"), style_id)
        r_pr.append(r_style)
    else:
        # 스타일이 없는 문서면 Word 기본 하이퍼링크 색을 직접 넣는다.
        color_node = OxmlElement("w:color")
        color_node.set(qn("w:val"), "0563C1")
        r_pr.append(color_node)
        underline = OxmlElement("w:u")
        underline.set(qn("w:val"), "single")
        r_pr.append(underline)

    fonts = OxmlElement("w:rFonts")
    fonts.set(qn("w:ascii"), "Malgun Gothic")
    fonts.set(qn("w:hAnsi"), "Malgun Gothic")
    fonts.set(qn("w:eastAsia"), "맑은 고딕")
    r_pr.append(fonts)
    run.append(r_pr)

    text_node = OxmlElement("w:t")
    text_node.text = text
    text_node.set(qn("xml:space"), "preserve")
    run.append(text_node)

    hyperlink.append(run)
    paragraph._p.append(hyperlink)


def _write_item(doc, item, style_id=None):
    label = f"{item.title} / {item.publication}" if item.publication else item.title
    paragraph = doc.add_paragraph(style="List Paragraph")
    paragraph.paragraph_format.space_after = Pt(2)
    if item.url:
        _add_styled_hyperlink(paragraph, label, item.url, style_id)
    else:
        core._set_run_font(paragraph.add_run(label))
    if item.summary:
        _para(doc, item.summary, align=WD_ALIGN_PARAGRAPH.JUSTIFY, space_after=6)


def build_docx(items, report_day: date, output_path: Path) -> Path:
    shutil.copyfile(REFERENCE_DOCX, output_path)
    doc = Document(str(output_path))
    core._clear_document_body(doc)
    style_id = hyperlink_style_id(doc)

    _para(doc, "Daily Monitoring Report", size=20, bold=True, color=GREEN, space_after=2)
    _para(doc, f"News Clipping List ({report_day:%y.%m.%d})", bold=True,
          color=DARK_GRAY, space_after=10)

    for major_key, major_label in MAJOR_SECTIONS:
        group = [i for i in items if i.major == major_key]
        if not group:
            continue

        _para(doc, major_label, style="No Spacing", size=20, bold=True, color=GREEN,
              align=WD_ALIGN_PARAGRAPH.LEFT, space_before=10, space_after=6)

        if major_key != "own":
            for item in group:
                _write_item(doc, item, style_id)
            continue

        ordered = [s for s in OWN_SUBGROUPS if any(i.subgroup == s for i in group)]
        extras = sorted({i.subgroup for i in group
                         if i.subgroup and i.subgroup not in ordered})
        for subgroup in ordered + extras:
            _para(doc, subgroup, bold=True, color=BLACK,
                  align=WD_ALIGN_PARAGRAPH.JUSTIFY, space_before=6, space_after=2)
            for item in [i for i in group if i.subgroup == subgroup]:
                _write_item(doc, item, style_id)
        for item in [i for i in group if not i.subgroup]:
            _write_item(doc, item, style_id)

    doc.save(str(output_path))
    return output_path


def output_filename(report_day: date) -> str:
    return f"Daily Monitoring Report_OASIS_{report_day:%y%m%d}.docx"


def generate(raw_links: str, report_day: date, output_dir: Path, progress=None):
    links = parse_input(raw_links)
    if not links:
        raise ValueError("링크를 찾지 못했습니다. http로 시작하는 주소를 넣어 주세요.")
    items = collect(links, progress=progress)
    output_dir.mkdir(parents=True, exist_ok=True)
    path = core._select_output_path(output_dir / output_filename(report_day))
    build_docx(items, report_day, path)
    return path, items
